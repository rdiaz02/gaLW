/***************************************************************************
                          ga.h  -  header file for the genetic algorithm
			  classes and methods. Implementation in ga.cpp
                             -------------------
    begin                : Mon Nov 27 2000
    copyright            : (C) 2000, 2004 by Ramon Diaz-Uriarte
    email                : rdiaz@ligarto.org
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include<valarray>
#include<vector>
#include<fstream>
#include<string>






using namespace std;

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
///////////////////////                                       ////////////////////////
///////////////////////           PopulationGenome            ////////////////////////
///////////////////////                                       ////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

// OJO: Populations are ALWAYS even numbered

/**
* esto es una prueba de la documentacion
*/

class PopulationGenome {
  int number_of_alleles;
  int population_size;
  vector<vector<double> > Population;
  //see Stroustrup, p. 836 for this way of making a matrix
  // individuals are rows, genes are columns.
  vector<vector<double> > Mating_Population;
//  vector<vector<double> > new_offspring; //used for OLG mating
  valarray<double> Score;
  valarray<double> Fitness;
  PopulationGenome(const PopulationGenome&); //to prevent pass by value
public:
  //~PopulationGenome(){cout <<"\n destructor called\n";} //just a check
  PopulationGenome(const int alleles, const int individuals); // will later add one that takes a file as input
  double GetGene(const int individual, const int allele) const {return Population[individual][allele];}
  double GetIndividualRawScore(const int individual) const {return Score[individual];}
  double GetMeanRawScore() const {return Score.sum()/population_size;}
  double GetMinRawScore() const {return Score.min();}
  double GetMaxRawScore() const {return Score.max();}
  double GetIndividualFitness(const int individual) const {return Fitness[individual];}
  void SetGene(const int individual, const int allele, double new_value) {Population[individual][allele] = new_value;}
  void SetIndividualRawScore(const int individual, const double newscore) {Score[individual] = newscore;}
  void OutputFileGenome(ofstream& thefile);
  void OutputFileGenome(ofstream& thefile, const int number);
  void ScreenOutScore();
  //remember:the SetFitness functions have to set the fitness so that it is the probability
  // of an individual to be chosen as a parent for next pop; thgus, they are necessarily population-based
  void SetFitnessRank(); 
  void SetFitnessLinear(); 
  void SetFitnessTruncation(const double truncated_fraction);

  void Mating();
  void MatingOLG(double, double, double);
  void UniformCrossOver(const float cover_prob);
  void OnePointCrossOver(const float cover_prob);
  void CrossOver(const float cover_prob, const string);
  void MutateGenome(const float umutate_prob);

  // the next three are the ones you might need to modify more often;
  // the last one you MUST customize for your problem
  double RandomAllele(const int locus_index); //returns a (valid) new allelle for locus locus_index
  double MutateAllele(const int locus_index, double previous_value); //returns a (valid) mutated allele
  void Objective(); //you define it; should fill up the Score array, using theSetIndividualRawScore
};




//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
///////////////////////                                       ////////////////////////
///////////////////////              GAControl                ////////////////////////
///////////////////////                                       ////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////


class GAControl {
  int num_alleles;
  int num_individuals;
  double mean_raw_score;
  valarray<double> mean_traits;
  valarray<double> SummaryQuartile;
  GAControl(const GAControl&); //to prevent pass by value
public:
  GAControl(const int, const int, const int);
  void SetMeanRawScore(const int generation, const double value);
  double GetMeanRawScore(const int generation);
  void SetMeanTraits(const int generation, PopulationGenome& );
  int GAMeanRawConvergence(const int generation, const float min_diff, const int stride);
  void OutputFileMeanTraits(ofstream& thefile, const int generation);
  void ScreenOutMeanTraits(const int generation, const string &s1);
  void SetMedianQuartileTraits(PopulationGenome&);
  void ScreenOutQuartileTraits(const int generation, const string &s1);
  void OutputFileMedianQuartileTraits(ofstream& thefile);
};

