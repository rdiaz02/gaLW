/***************************************************************************
    copyright            : (C) 2000, 2004 by Ram�n D�az-Uriarte
    email                : rdiaz@ligarto.org
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


#include<valarray>
#include<cstdlib>
#include<iostream>

#include<random/uniform.h> //Blitz's discrete uniform 
#include<random/discrete-uniform.h> //Blitz's discrete uniform 
#include<blitz/array.h> //Blitz's arrays


using namespace std;
using namespace ranlib; //Blitz's random number
using namespace blitz; //Blitz's arrays




inline int random_number_2(int n) {DiscreteUniform<int> x(n); return x.random();} //a random number 0,..,n-1

template <class Ran>
inline void random_shuffle_2(Ran first, Ran last); 


void Prob_F_Matrix_Init(Array<double,2>& Prob_F_Matrix, const double P_Within_Cluster, 
			const int ClusterSize, const int population_size);



inline int Prob_Sampling_Index(const Array<double,1> &VectorProbs);



valarray<int> Choose_Fighting_Pairs(const Array<double, 2> &Prob_F_Matrix, const int number_fighting_pairs, const int population_size);


int main (int argc, char *argv[])
{

  unsigned int RandomSeed;
  unsigned int population_size;
  double P_No_Fight;
  unsigned int ClusterSize;
  double P_Within_Cluster;


// Parsing command line arguments

  for(int ii=1; ii<(argc-1); ii++) {
    if(strcmp(argv[ii],"seed") == 0) RandomSeed=(unsigned int)atoi(argv[ii+1]);
    if(strcmp(argv[ii],"popsize") == 0) population_size=(unsigned int) atoi(argv[ii+1]);
    if(strcmp(argv[ii],"pnofight") == 0) P_No_Fight=atof(argv[ii+1]);
    if(strcmp(argv[ii],"clustersize") == 0) ClusterSize=(unsigned int)atoi(argv[ii+1]);
    if(strcmp(argv[ii],"pwcluster") == 0) P_Within_Cluster=atof(argv[ii+1]);
  }

if(argc != 11) {
cout << "\nNeed to input:\n";
cout << "-seed xx: the seed of the random number generator;\n";
cout << "-popsize: population size;\n";
cout << "-pnofight: probability an animal does not fight, per period\n";
 cout << "-clustersize: size of clusters where prob. of fitht is largest; a value\n";
 cout << "\t of 1 is the same as a uniform prob. over the whole population.\n";
 cout << "-pwcluster: prob. of fight within cluster.\n"; 
  return 1;
}


int number_fighting_pairs = static_cast<int>(rint(population_size * 0.5 * (1-P_No_Fight)));

 if (abs(static_cast<double>(number_fighting_pairs)- (population_size * 0.5 * (1-P_No_Fight)))>1.0e-9)
   {
   cout<<"\n WARNING: Number of fighting pairs not an integer multiple of 1-P_No_Fight \n";
 cout << " I will use " << number_fighting_pairs << " but value is " <<(population_size * 0.5 * (1-P_No_Fight))<< endl;
   }



// Add a few checks: all probs >=0, sum of probs = 1, etc.
// Check that pop_size is an integer multiple of ClusterSize




Uniform<double> dummy;
dummy.seed(RandomSeed); //to initialize the random number generator



// These lines should be global stuff;
// The matrix with probability of fights; creating and initializing;
Array<double, 2> Prob_F_Matrix(population_size,population_size);
Prob_F_Matrix_Init(Prob_F_Matrix, P_Within_Cluster, ClusterSize, population_size);

 valarray<int> Fighting_Pairs(2*number_fighting_pairs);
 Fighting_Pairs = Choose_Fighting_Pairs(Prob_F_Matrix, number_fighting_pairs, population_size);

 cout << endl;
 for (int ll=0; ll<2*number_fighting_pairs; ll++) cout << Fighting_Pairs[ll]<<endl;
 cout << endl;


 return 0;
}



template <class Ran>
inline void random_shuffle_2(Ran first, Ran last) {
  // copied from stl_algo.h, but I modify the call to the random number
  // generator to have control over it

  if (first == last) return;
  for (Ran i = first + 1; i != last; ++i)
    iter_swap(i, first + random_number_2((i - first) + 1));
}




inline int Prob_Sampling_Index(const Array<double,1> &VectorProbs)
{
 // For sampling ONE element with probability 
  // given by VectorProbs, a vector of probabilities.
  // Will return the index of the vector sampled

  // OJO, OJO: si sum. probs <1, el inidce retornado puede
  // ser > size of input vector!!


  // Improvement: since the largest element is likely to be
  // that of an element with itself, we could also use a cshift()
  // to start the iteration with the largest element.
  // call would be: (..., value_cshift = 0)
  // if value_cshift=0 leave as here;
  // otherwise cshift; but there should be an easy way to
  // find out by how much to shift; note also that we need to create a new
  // temporary object to hold the shift, etc.

    UniformClosed<double> blitz_rnumber;
    double random = blitz_rnumber.random();

    double mass = 0.0;
    int i = 0;
    for(i = 0; i < VectorProbs.size() ; i++){
      //     if(VectorProbs(i) > 1.0e-9) to prevent an animal with 0 prob to be chosen
      //	{
	mass += VectorProbs(i); 
	if(random <= mass) break;
	//  }
    }
    return i;
}


void Prob_F_Matrix_Init(Array<double,2>& Prob_F_Matrix, const double P_Within_Cluster, 
			const int ClusterSize, const int population_size)
{  // Initialize the matrix with prob. of fights

  //A uniform matrix; P_Within_Cluster irrelevant
  if(ClusterSize==1) Prob_F_Matrix = static_cast<double>(1.0/(population_size-1));

  //All other cases
  if (ClusterSize > 1) { 
    Prob_F_Matrix = (1-P_Within_Cluster)/(population_size-ClusterSize);//fill the off-block.
    for(int i = 0; i <= (population_size-ClusterSize); i+=ClusterSize)
      Prob_F_Matrix(Range(i,i+ClusterSize-1),Range(i,i+ClusterSize-1)) = P_Within_Cluster/(ClusterSize-1); // fill the diagonal blocks;
  }

  // set diagonal to zero since no animal fights with itself

 for (int i = 0; i<population_size; i++) Prob_F_Matrix(i,i) = 0.0;
}








valarray<int> Choose_Fighting_Pairs(const Array<double, 2> &Prob_F_Matrix, const int number_fighting_pairs, const int population_size)
{

  // OJO: this is the code in pairs-test6c.cc;
  // might want to change it; and could do some optimizing too.

  valarray<int> fight_pairs(-9,2*number_fighting_pairs); //I keep the pairs in a vector; two successive indivs form a pair.
  Array<double,2> tmp_Prob_F_Matrix(population_size, population_size);
  Array<double,1> sum_indiv_probs(population_size);
  Array<double,1> sum_indiv_probs_tmp(population_size);
  int indiv_1, indiv_2;
  int num_fighters=0;
  tmp_Prob_F_Matrix = Prob_F_Matrix;
  fight_pairs=-9;

   // OPTIMIZING: might gain some speed using valarrays instead of Array of 1 dimension? 

  while(num_fighters < 2*number_fighting_pairs ) {
   // Logic: select the first indiv based on its overall prob, of fighting (sum of probs of fighting with others);
   // then select its oponent, based on the row of the matrix; might need to scale to add up to 1.
   // finally, set those elements to zero (whole rows, and the cols. with those indivs).
    secondIndex jj;
    sum_indiv_probs = sum(tmp_Prob_F_Matrix, jj); 
    double sum_of_sums = sum(sum_indiv_probs);
    sum_indiv_probs_tmp = sum_indiv_probs/sum_of_sums; //scale to 1
    indiv_1 = Prob_Sampling_Index(sum_indiv_probs_tmp); //here we choose the first indiv
    tmp_Prob_F_Matrix(indiv_1, Range::all())/=sum_indiv_probs[indiv_1]; //scale to 1
    indiv_2 = Prob_Sampling_Index(tmp_Prob_F_Matrix(indiv_1,Range::all()));
    
    tmp_Prob_F_Matrix(Range::all(), indiv_1) = 0.0; //Optimizing: not needed to set to zero in the last loop;
    tmp_Prob_F_Matrix(Range::all(), indiv_2) = 0.0; //instead of while, use for(;;) and break out of
    tmp_Prob_F_Matrix(indiv_1, Range::all()) = 0.0; //loop when num_fighters=2*number_fighting_pairs;
    tmp_Prob_F_Matrix(indiv_2, Range::all()) = 0.0; //place these four lines at end of loop
                                                  //right after chcking num_fighters=2*number... 
    fight_pairs[num_fighters]=indiv_1;
    fight_pairs[++num_fighters]=indiv_2;

    ++num_fighters;//Note this is the location of the NEXT indiv in the fight_pairs valarray; 
                 //when exiting this loop, the last indiv's index  is in num_fighters-1.
  }

 return fight_pairs;
}



