/***************************************************************************
                          main.cpp  - The main program...
	  Uses the fast algorithm for selecting fighting pairs
	  (see ~/loser/tested-code/pairs-test5h5.cc); 
	  number of fighters and number of switchers
	  are truly random variables now, so prob. of fight and switching 
	  can now be arbitrarily small or large.
	  The FightAnd Update function is now passed as a pointer to
	  function to minimize evaluation of conditionals
	  within what is, probably, the most often called
	  function in the program.
	  
     DEPENDENCIES: 
     I also wrote and use:
	  - ga.h and ga.cpp (the genetic algorithm)
	  - fighting.cpp (the fighting routines)
	  - RandomUtil.h (basically a wrapper for the random
	                  number generators, plus a few other utilites 
			  I wrote).
     To compile you also need:
          - libRmath.a and Rmath.h, the R standalone random number utilites;
	          the binomial random number generator is ALWAYS used in 
		  the fighting.cpp file. (always link to -lRmath).
	  - Blitz++: this is optional, and allows you to use Blitz's random
	          numbers (gamma, normal, uniform). If you want to use
		  Blitz, compile using -DBL_RANDOM_NUM; if you don't,
		  then you'll use R's with -DR_RANDOM_NUM.
		  You'll also need to link to -lblitz if you use Blitz.
	      
	  
	  

                             -------------------
    begin                : Wed Dec 13 17:12:03 CET 2000
    copyright            : (C) 2000, 2004 by Ram�n D�az-Uriarte
    email                : rdiaz@ligarto.org
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include<fstream>
#include<string>
#include<algorithm>
#include<valarray>
#include<vector>
#include<ctime> //to seed the random number generators, if no seed is explicitly given
#include<cmath>

//#include<blitz/array.h> //Blitz's arrays

#ifdef BL_RANDOM_NUM //using Blitz's random numbers?
#include<random/normal.h> //Blitz's random number
#include<random/gamma.h> //ditto
#endif

#ifdef R_RANDOM_NUM //using R's random numbers?
#define MATHLIB_STANDALONE   
#include <Rmath.h>

#endif


#include"ga.h" //my genetic algorith headers; see ga.cpp for code.
#include"RandomUtil.h" //the random number and other prob. routines; most are inlines; no object file;


#undef DEBUG
#ifdef DEBUG
#define PR(x) cout << #x " = " << x << '\n';
#endif



using namespace std;
//using namespace blitz;

double random_number_counter = 0;

class GlobalVars {
// Used to hold global variables that need to be accessed by various
// functions, but are only modified at the begining of main.

// Also holds the random number generator, that this way have
// direct access to the necessary variables
  
  string crossover_type;
  string mutation_off_limits;
  string fitness_type;
  string type_mutation; // one of NewOne or Modify
  double crossover_probability;
  double mutation_probability;
  double initial_gamma_mean;
  double initial_normal_mean;
  double mutation_normal_mean;
  double initial_normal_sdev;
  double mutation_normal_sdev;
  double mutation_normal_sdev_small;
  double truncation_fraction; 
  int number_alleles;
  int number_individuals;
  int number_of_generations;
  unsigned int RandomSeed;
  unsigned int RandomSeed2;
  int number_times_total_output;
  double OLG_replace_fraction;
  bool OLG;
  int first_migration;

  double p_fight;
  int ClusterSize;
  //  double P_Within_Cluster;
  double p_switch;
  //int number_switchers;
  int number_periods;
  double strength_gamma_mean; 
  double fight_gain;
  double fight_cost;
  string type_conflict;
  string type_cost;
  //  int number_fighting_pairs;
  double strength_lw_ratio;
  double cost_factor;
  int migration_interval;
  double baseline;
  double RHP_reliability;
  int typeHD;
  GlobalVars(const GlobalVars&); // to make sure never passed by value
 public:
  GlobalVars();
  void Set_crossover_type(string s) {crossover_type = s;}
  void Set_mutation_off_limits(string s) {mutation_off_limits = s;}
  void Set_fitness_type(string s) {fitness_type = s;}
  void Set_crossover_probability(double x) {crossover_probability = x;}
  void Set_mutation_probability(double x) {mutation_probability = x;}
  void Set_initial_gamma_mean(double x) {initial_gamma_mean = x;}
  void Set_initial_normal_mean(double x) {initial_normal_mean = x;}
  void Set_mutation_normal_mean(double x) {mutation_normal_mean = x;}
  void Set_initial_normal_sdev(double x) {initial_normal_sdev = x;}
  void Set_mutation_normal_sdev(double x) {mutation_normal_sdev = x;}
  void Set_mutation_normal_sdev_small(double x) {mutation_normal_sdev_small = x;}
  void Set_truncation_fraction(double x) {truncation_fraction = x;} 
  void Set_number_alleles(int x) {number_alleles = x;}
  void Set_number_individuals(int x) {number_individuals = x;}
  void Set_number_of_generations(int x) {number_of_generations = x;}
  void Set_RandomSeed(unsigned int x) {RandomSeed = x;}
  void Set_RandomSeed2(unsigned int x) {RandomSeed2 = x;}
  void Set_number_times_total_output(int x) {number_times_total_output = x;}
  void Set_type_mutation(string s) {type_mutation = s;}
  void Set_migration_interval(int x) {migration_interval = x;}
  void Set_baseline(double x) {baseline = x;}
  void Set_OLG_replace_fraction(double x) {OLG_replace_fraction = x;}
	void Set_OLG(int x) {OLG = x;}
  void Set_p_fight(double x) {p_fight = x;}
  void Set_ClusterSize(int x) {ClusterSize = x;}
  //  void Set_P_Within_Cluster(double x) {P_Within_Cluster = x;}
  void Set_p_switch(double x) {p_switch = x;}
  void Set_number_periods(int x) {number_periods = x;}
  void Set_strength_gamma_mean(double x) {strength_gamma_mean = x;} 
  void Set_fight_gain(double x) {fight_gain = x;}
  void Set_fight_cost(double x) {fight_cost = x;}
  void Set_type_conflict(string s) {type_conflict = s;}
  //void Set_number_fighting_pairs(unsigned int x) {number_fighting_pairs = x;}
  void Set_strength_lw_ratio(double x) {strength_lw_ratio = x;}
//  void Set_number_switchers(unsigned int x) {number_switchers = x;}
  void Set_cost_factor(double x) {cost_factor = x;}
  void Set_type_cost(string s) {type_cost = s;}
  void Set_RHP_reliability(double x) {RHP_reliability = x;}
  void Set_typeHD(int x) {typeHD = x;}
  void Set_first_migration(int x) {first_migration = x;}

  string Get_crossover_type() const {return crossover_type;}
  string Get_mutation_off_limits() const {return mutation_off_limits;} 
  string Get_fitness_type() const {return fitness_type;}  
  double Get_crossover_probability() const {return crossover_probability;}
  double Get_mutation_probability() const {return mutation_probability;}
  double Get_initial_gamma_mean() const {return initial_gamma_mean;} 
  double Get_initial_normal_mean() const {return initial_normal_mean;} 
  double Get_mutation_normal_mean() const {return mutation_normal_mean;}
  double Get_initial_normal_sdev() const {return initial_normal_sdev;} 
  double Get_mutation_normal_sdev() const {return mutation_normal_sdev;}
  double Get_mutation_normal_sdev_small() const {return mutation_normal_sdev_small;}
  double Get_truncation_fraction() const {return truncation_fraction;} 
  int Get_number_alleles() const  {return number_alleles;}
  int Get_number_individuals() const {return number_individuals;}
  double Get_p_fight() const  {return p_fight;}  
  //  double Get_P_Within_Cluster() const {return P_Within_Cluster;} 
  double Get_p_switch() const {return p_switch;} 
  double Get_strength_gamma_mean() const {return strength_gamma_mean;} 
  double Get_fight_gain() const {return fight_gain;} 
  double Get_fight_cost() const {return fight_cost;} 
  double Get_strength_lw_ratio() const {return strength_lw_ratio;} 
  double Get_cost_factor() const {return cost_factor;}
  int Get_number_of_generations() const {return number_of_generations;}
  unsigned int Get_RandomSeed() const {return RandomSeed;}
  unsigned int Get_RandomSeed2() const {return RandomSeed2;}
  int Get_number_times_total_output() const {return number_times_total_output;}
  //  int Get_number_switchers() const {return number_switchers;}
  int Get_ClusterSize() const {return ClusterSize;}
  int Get_number_periods() const {return number_periods;}
  string Get_type_conflict() const {return type_conflict;}
  //int Get_number_fighting_pairs() const {return number_fighting_pairs;}
  string Get_type_cost() const {return type_cost;}
  string Get_type_mutation() const {return type_mutation;}
  void PrintParams(ofstream &thefile); //print out all parameters to a file
  int Get_migration_interval() const {return migration_interval;}
  double Get_baseline() const {return baseline;}
  double Get_OLG_replace_fraction() const {return OLG_replace_fraction;}
  bool Get_OLG() const {return OLG;}
  double Get_RHP_reliability() const {return RHP_reliability;}
  int Get_typeHD() const {return typeHD;}
  int Get_first_migration() const {return first_migration;}

#ifdef BL_RANDOM_NUM
  double InitialGamma() {
    ++random_number_counter;
    ranlib::Gamma<double> x(initial_gamma_mean);
    return x.random();
  }

  double InitialNormal() {
    ++random_number_counter;
    ranlib::Normal<double> x(initial_normal_mean, initial_normal_sdev);
    return x.random();
  }

  double MutationNormal() {
    ++random_number_counter;
    ranlib::Normal<double> x(mutation_normal_mean, mutation_normal_sdev);
    return x.random(); }

  double MutationNormalSmall() { //small variance
    ++random_number_counter;
    ranlib::Normal<double> x(mutation_normal_mean, mutation_normal_sdev_small);
    return x.random(); }

#endif


#ifdef R_RANDOM_NUM
  double InitialGamma() {
    ++random_number_counter;
    return rgamma(initial_gamma_mean, 1);
    }

  double InitialNormal() {
    ++random_number_counter;
   return rnorm(initial_normal_mean, initial_normal_sdev);
  }

  double MutationNormal() {
    ++random_number_counter;
    return rnorm(mutation_normal_mean, mutation_normal_sdev);
  }

  double MutationNormalSmall() {
    ++random_number_counter;
    return rnorm(mutation_normal_mean, mutation_normal_sdev_small);
  }

#endif

} GVars;


GlobalVars::GlobalVars() {
  crossover_type = "Uniform"; //Uniform or OnePoint, but OnePoint not fully tested yet
  mutation_off_limits = "Truncate"; //Truncate or Replace; only with mutation_type==Modify
  fitness_type = "Truncation"; //Truncation or Rank
  type_mutation = "Modify"; //NewOne or Modify
  crossover_probability = 0.5;
  mutation_probability = 0.005;
  initial_gamma_mean = 1.0; //this is an exponential if you set the param = 1.0
  initial_normal_mean = 0.0; //you can change it, but this is the only thing that will make sense in most cases
  mutation_normal_mean = 0.0; //ditto
  initial_normal_sdev = 10;
  mutation_normal_sdev = 0.5;  //only affects if type_mutation==Modify
  mutation_normal_sdev_small = 0.02;  //only affects if type_mutation==Modify
  truncation_fraction = .20; //very close to the value in Sumida et al., 1990.
  number_alleles = 5;
  number_individuals = 20;
  number_of_generations = 5000;
//  RandomSeed = static_cast<unsigned int>(time(0));
  number_times_total_output = 10;
  fight_gain = 0.5;
  fight_cost = 1.0; //only applies to Hawk-Dove-type game, not to War of Attrition
  p_fight = 0.2;
  ClusterSize = 2;
  //  P_Within_Cluster = 1.0;
  p_switch = 0.2;
  number_periods = 500;
  strength_gamma_mean = 3.0;
  type_conflict = "WA"; //can be WA for war of attrition or HD for Hawk-Dove;
  type_cost = "SizeRatio"; //Only applies to War of Attrition; "Simple" for the traditional WA, SizeRatio with size relevant as in Enquist & Leimar
//  number_fighting_pairs = 10;
  strength_lw_ratio = 1;
  cost_factor = 0.1;
  migration_interval = 20;
  baseline = 5;
  OLG = true;
  OLG_replace_fraction = 0.2;
  RHP_reliability = 1.0;
  typeHD = -1;
  first_migration = 0;
}

void GlobalVars::PrintParams(ofstream &thefile) {
  thefile << "\n crossover_type              "<< crossover_type;            
  thefile << "\n type_mutation               "<< type_mutation;
  thefile << "\n mutation_off_limits         "<< mutation_off_limits;       
  thefile << "\n fitness_type                "<< fitness_type;              
  thefile << "\n crossover_probability       "<< crossover_probability     ;
  thefile << "\n mutation_probability        "<< mutation_probability      ;
  thefile << "\n initial_gamma_mean          "<< initial_gamma_mean        ;
  thefile << "\n initial_normal_mean         "<< initial_normal_mean       ;
  thefile << "\n mutation_normal_mean        "<< mutation_normal_mean      ;
  thefile << "\n initial_normal_sdev         "<< initial_normal_sdev       ;
  thefile << "\n mutation_normal_sdev        "<< mutation_normal_sdev      ;
  thefile << "\n mutation_normal_sdev_small  "<< mutation_normal_sdev_small;
  thefile << "\n truncation_fraction         "<< truncation_fraction       ;
  thefile << "\n number_alleles              "<< number_alleles            ;
  thefile << "\n number_individuals          "<< number_individuals        ;
  thefile << "\n number_of_generations       "<< number_of_generations ;
  thefile << "\n RandomSeed                  "<< RandomSeed                ;
  thefile << "\n RandomSeed2                 "<< RandomSeed2               ;
  thefile << "\n number_times_total_output   "<< number_times_total_output ;
  thefile << "\n p_fight                     "<< p_fight                ;
  thefile << "\n ClusterSize                 "<< ClusterSize               ;
  //thefile << "\n P_Within_Cluster            "<< P_Within_Cluster          ;
  thefile << "\n p_switch                    "<< p_switch           ;
  //  thefile << "\n number_switchers            "<< number_switchers          ;
  thefile << "\n number_periods              "<< number_periods            ;
  thefile << "\n strength_gamma_mean         "<< strength_gamma_mean       ;
  thefile << "\n fight_gain                  "<< fight_gain                ;
  thefile << "\n fight_cost                  "<< fight_cost                ;
  thefile << "\n type_conflict               "<< type_conflict             ;
  thefile << "\n type_cost                   "<< type_cost                 ;
  //  thefile << "\n number_fighting_pairs       "<< number_fighting_pairs     ;
  thefile << "\n strength_lw_ratio           "<< strength_lw_ratio         ;
  thefile << "\n cost_factor                 "<< cost_factor                  ;             
  thefile << "\n migration_interval          "<< migration_interval           ;            
  thefile << "\n baseline                    "<< baseline                    ;             
  thefile << "\n OLG_replace_fraction        "<<OLG_replace_fraction;
  thefile << "\n RHP_reliability             "<<RHP_reliability     ;
  thefile << "\n typeHD                      "<<typeHD     ;
  thefile << "\n first_migration             "<<first_migration;
  thefile << endl;
}





// These are the ga functions that must be user defined.

double PopulationGenome::RandomAllele(const int locus_index) {
  // you need to specify how a new allele is obtained when the population is
  // initialized; by default, we assume random normal variates
  double r_value;
  switch(locus_index) {
    //  case 0:
    //    r_value = GVars.InitialNormal();
    //    break;
  case 0:
    if (GVars.Get_typeHD() == 1) r_value = GVars.Get_fight_gain()/GVars.Get_fight_cost();
    else if (GVars.Get_typeHD() == 2) {
      if ((GVars.Get_fight_gain() - GVars.Get_fight_cost()) > 0) 
	r_value = log(GVars.Get_fight_gain()/(GVars.Get_fight_gain() -GVars.Get_fight_cost()));
      else r_value = GVars.InitialNormal();
    }
    else if(GVars.Get_typeHD() == 0) r_value = ReturnUniformClosed();
    //i.e., war of attrition like
    else r_value = GVars.InitialGamma();
    break;
  case 1:
    r_value= ReturnUniformOpen();
    break;
  case 2:
    r_value = ReturnUniformOpen();
    break;
  default:
    r_value = GVars.InitialNormal();
  }
  return r_value;
}

int num_times_mutation = 0; //to check if bugs within mutation

double PopulationGenome::MutateAllele(const int locus_index, const double previous_value) {
  // How the mutated alleles are generated;
	// two big options: NewOne (i.e., obtain a new allele from set of allowed alleles)
	// or Modify (add a normal variate to the previous value). In the later, if
	// the new value steps out of the range, there are two options:
        // draw a new normal variate until the generated or truncate.

  ++num_times_mutation ; //to check if bugs within mutation

  if(GVars.Get_type_mutation() == "NewOne") { //return RandomAllele(locus_index); // now diasbled
    cout << "\n this feature is not implemented now; use Modify \n";
    exit(1);
  }

  else { // type_mutation == Modify
  double new_value;
  // if we go out of limits, we are left at the limits;
  if(GVars.Get_mutation_off_limits() == "Truncate") {
    switch(locus_index) { 
    case 0:
      if ((GVars.Get_typeHD() == 1) || (GVars.Get_typeHD()==0)) {       
	new_value = previous_value + GVars.MutationNormalSmall();
	if (new_value <= 0.0) new_value=0.0000000001;
	else if (new_value >= 1.0) new_value=0.9999999999;
      }
      else if (GVars.Get_typeHD() == 2) new_value = previous_value + GVars.MutationNormal();
      else { //war of attrition
	new_value =  previous_value + GVars.MutationNormal();
	if (new_value <0.0) new_value = 0.0;
      }
      break;
    case 1:
	  new_value = previous_value + GVars.MutationNormalSmall();
	  if (new_value <= 0.0) new_value=0.0000000001;
	  else if (new_value >= 1.0) new_value=0.9999999999;
    break;

    case 2:
	  new_value = previous_value + GVars.MutationNormalSmall();
	  if (new_value <= 0.0) new_value=0.0000000001;
	  else if (new_value >= 1.0) new_value=0.9999999999;
    break;

    default:
      new_value = previous_value + GVars.MutationNormal();
    }
  } 
 
  else if(GVars.Get_mutation_off_limits() == "Replace") {
  // Here we draw a new random number if we go out of limits;
    switch(locus_index) {
    case 0:
      if ((GVars.Get_typeHD() == 1) || (GVars.Get_typeHD() == 0)) { 	
	do {
	    new_value = previous_value + GVars.MutationNormalSmall();
	  } while (new_value <= 0.0 || new_value >= 1.0);      
      }
      else if (GVars.Get_typeHD() == 2) new_value = previous_value + GVars.MutationNormal();
      else { //war of attrition
	do { new_value =  previous_value + GVars.MutationNormal();
	}
	while (new_value <0.0) ;
      }
      break;
    case 1:
	do {
	    new_value = previous_value + GVars.MutationNormalSmall();
	  } while (new_value <= 0.0 || new_value >= 1.0);
    break;

    case 2:
	  do {
	    new_value = previous_value + GVars.MutationNormalSmall();
	  } while (new_value <= 0.0 || new_value >= 1.0);
    break;

    default:
      new_value = previous_value + GVars.MutationNormal();
    } //switch
  } //else if
  return new_value;
  }
}


void PopulationGenome::Objective() {}; //I don't use this


void ExchangeChromosomesOld(PopulationGenome &giver, PopulationGenome &receiver, const int PopulationSize, const int NumberAlleles) { 
// for deme structures
    int j = ReturnDiscreteUniform(PopulationSize);
    int k = ReturnDiscreteUniform(PopulationSize);
    for (int i = 0; i < NumberAlleles; i++) receiver.SetGene(j, i, giver.GetGene(k, i));
}


void ExchangeChromosomes(PopulationGenome &g1, PopulationGenome &g2, const int PopulationSize, const int NumberAlleles, const int generation, const int detail_first, const int detail_last, ofstream &thedetailfile) { 
// for deme structures; transfer individuals in both directions (g1 -> g2 and g2 -> g1)
    vector<double> tmp(NumberAlleles);
    int j = ReturnDiscreteUniform(PopulationSize);
    if ((generation >= detail_first) && (generation <= detail_last)) thedetailfile <<"\n migrant is " <<j<<'\n';
    for (int i = 0; i < NumberAlleles; i++) {
      tmp[i] = g1.GetGene(j, i);
      g1.SetGene(j, i, g2.GetGene(j, i));
      g2.SetGene(j, i, tmp[i]);
    }
}




// The whole file with all the within-generation stuff
// (matrix updating, selection of fighters, fights, etc)
// is in fighting.cpp, but all we need here is just:

// (A note: I found that FightAndUpdate, as written originally, was spending
// a good amount of time evaluate conditionals, in particular 
// type of fight and cost of fight. But the type of cost and fight
// are fixed once the run starts, so there is no need to evaluate those conditionals.
// Thus, I have three functions (the three FightAndUpdate below), one for each case,
// without any conditional.
// At the begingin of main, I create a function pointer that, dependening
// on whether it is HD, or WA or WA with SizeRatio cost, points to
// one of the three functions. Then, this pointer to function is passed
// to "Within_Generation_Proc". This does not change within a run.
// I now save about 10% of time.)

class PopulationNonGenome;


void Within_Generation_Proc(PopulationGenome &g, const std::vector<int> &Prob_F_Matrix, const int &PopulationSize, 
			    const double &p_fight, const int &number_periods, const double &p_switch, const int &ClusterSize, 
			    const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability,
			    const double &cost_factor, const double &strength_gamma_mean, const double &baseline, 
			    const int &generation, const bool output_all, const string &population_name, ofstream &theoutputfile,
			    const int detail_first, const int detail_last, ofstream &thedetailedfile, const int &type_HD, 
			    void (*FightAndUpdate) (const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile));




void FightAndUpdateHD1(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, 
			const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, 
			const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, 
		       const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile);

void FightAndUpdateHD2(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, 
			const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, 
			const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, 
		       const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile);

void FightAndUpdateHD0(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, 
			const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, 
			const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, 
		       const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile);



void FightAndUpdateWASR(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p,
			const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, 
			const double &fight_gain, const double &strength_lw_ratio, const double &RHPrel, const double &cost_factor,
			const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile);

void FightAndUpdateWA(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, 
		      const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, 
		      const double &fight_gain, const double &strength_lw_ratio, const double &RHPrel, const double &cost_factor,
		      const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile);




/*

void FightAndUpdateWASR(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, 
			const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, 
			const double &fight_gain, const double &strength_lw_ratio, const double &cost_factor, 
			const double &baseline, const int period);

void FightAndUpdateWA(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, 
		      const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, 
		      const double &fight_gain, const double &strength_lw_ratio, const double &cost_factor, 
		      const double &baseline, const int period);

void FightAndUpdateHD(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, 
		      const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, 
		      const double &fight_gain, const double &strength_lw_ratio, const double &cost_factor, 
		      const double &baseline, const int period);
*/


void OutputAll(ofstream &thefile);

vector<int> VectorInit(const int ClusterSize, const int PopulationSize);






//int num_times_within_cluster = 0; //to count how often we get indivs. from same cluster in fights;			

double count_num_fighting_pairs = 0.0;
double count_num_switchers = 0.0;

// Esto ya es el GA
int main(int argc, char *argv[])
{

/*
  string out_mean_stats = "OutputMeanStatistics";
  string out_median_stats = "OutputMedianStatistics";
  string out_genot = "OutputGenotype";
*/

  GVars.Set_RandomSeed(static_cast<int>(time(0))); //in case no random seed passed
  GVars.Set_RandomSeed2(static_cast<int>(time(0))+3); //in case no random seed passed

  int detail_first = 10000000;
  int detail_last = 10000000;
// Parsing command line arguments and related stuff
  for(int ii=1; ii<(argc-1); ii++) {
    if(strcmp(argv[ii],"--seed") == 0) GVars.Set_RandomSeed(static_cast<int> (atoi(argv[ii+1])));
    if(strcmp(argv[ii],"--seed2") == 0) GVars.Set_RandomSeed2(static_cast<int> (atoi(argv[ii+1])));
    if(strcmp(argv[ii],"--popsize") == 0) GVars.Set_number_individuals(atoi(argv[ii+1]));
    if(strcmp(argv[ii],"--timesout") == 0) GVars.Set_number_times_total_output(atoi(argv[ii+1]));
    if(strcmp(argv[ii],"--coverprob") == 0) GVars.Set_crossover_probability(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--mutprob") == 0) GVars.Set_mutation_probability(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--basegamma") == 0) GVars.Set_initial_gamma_mean(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--initsdev") == 0) GVars.Set_initial_normal_sdev(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--mutsdev") == 0) GVars.Set_mutation_normal_sdev(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--mutsdevS") == 0) GVars.Set_mutation_normal_sdev_small(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--truncfrac") == 0) GVars.Set_truncation_fraction(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--generat") == 0) GVars.Set_number_of_generations(atoi(argv[ii+1]));
    if(strcmp(argv[ii],"--covertype") == 0) GVars.Set_crossover_type(argv[ii+1]);
    if(strcmp(argv[ii],"--mutoff") == 0) GVars.Set_mutation_off_limits(argv[ii+1]);
    if(strcmp(argv[ii],"--fittype") == 0) GVars.Set_fitness_type(argv[ii+1]);
    if(strcmp(argv[ii],"--tconfl") == 0) GVars.Set_type_conflict(argv[ii+1]);
    if(strcmp(argv[ii],"--tmutation") == 0) GVars.Set_type_mutation(argv[ii+1]);

    if(strcmp(argv[ii],"--fgain") == 0) GVars.Set_fight_gain(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--fcost") == 0) GVars.Set_fight_cost(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--tcost") == 0) GVars.Set_type_cost(argv[ii+1]);
    if(strcmp(argv[ii],"--stlwratio") == 0) GVars.Set_strength_lw_ratio(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--costfact") == 0) GVars.Set_cost_factor(atof(argv[ii+1]));

    if(strcmp(argv[ii],"--pfight") == 0) GVars.Set_p_fight(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--clustersize") == 0) GVars.Set_ClusterSize(atoi(argv[ii+1]));
    //    if(strcmp(argv[ii],"--pwcluster") == 0) GVars.Set_P_Within_Cluster(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--pswitch") == 0) GVars.Set_p_switch(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--nperiods") == 0) GVars.Set_number_periods(atoi(argv[ii+1]));
    if(strcmp(argv[ii],"--strgamma") == 0) GVars.Set_strength_gamma_mean(atof(argv[ii+1]));

  //  if(strcmp(argv[ii],"--outstats1") == 0) out_mean_stats = argv[ii+1];
  //  if(strcmp(argv[ii],"--outstats2") == 0) out_median_stats = argv[ii+1];
  //  if(strcmp(argv[ii],"--outgenot") == 0) out_genot = argv[ii+1];
    if(strcmp(argv[ii],"--minterv") == 0) GVars.Set_migration_interval(atoi(argv[ii+1]));
    if(strcmp(argv[ii],"--baseline") == 0) GVars.Set_baseline(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--OLGfract") == 0) GVars.Set_OLG_replace_fraction(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--OLG") == 0) GVars.Set_OLG(atoi(argv[ii+1]));
    if(strcmp(argv[ii],"--RHPrel") == 0) GVars.Set_RHP_reliability(atof(argv[ii+1]));
    if(strcmp(argv[ii],"--typeHD") == 0) GVars.Set_typeHD(atoi(argv[ii+1]));
    if(strcmp(argv[ii],"--firstmigr") == 0) GVars.Set_first_migration(atoi(argv[ii+1]));
    if(strcmp(argv[ii],"--detailfirst") == 0) detail_first = atoi(argv[ii+1]);
    if(strcmp(argv[ii],"--detaillast") == 0) detail_last = atoi(argv[ii+1]);
  }

  if(strcmp(argv[1],"--help") == 0) {
    // xx: aqui va el help message
  }

  if(argc < 2) {
    //xx: aqui va el texto sobre el run using default values
  } 

  // A variety of checks

	if(GVars.Get_number_of_generations() < GVars.Get_number_times_total_output()) {
  	cout << "\n **** ERROR ************: Number of generations has to be larger or equal than number of times total output \n";
  	cout << "\n \t that by default is set to 10. \n";
  	exit(1);
  	}


  if (GVars.Get_number_individuals()%GVars.Get_ClusterSize()) {
    cout << "\n ************* ERROR ***************** \n";
    cout << "Population size is not an integer multiple of cluster size";
    cout <<"\n since this must surely be an error \n";
    cout << "and some algorithms might produce weird things, I am bailing out.\n";
    exit(1);
  }

  if (GVars.Get_ClusterSize() == 1) {
      cout << "\n ****************ERROR******************* \n";
      cout << " Cluster size cannot be 1\n";
      exit(1);
  }





  seed_the_generator(GVars.Get_RandomSeed(), GVars.Get_RandomSeed2());

	
  //define the output files

  ofstream OutMeanStatistics1("MeanStatsPop1");
  ofstream OutMeanStatistics2("MeanStatsPop2");
  ofstream OutMeanStatistics3("MeanStatsPop3");
  ofstream OutMeanStatistics4("MeanStatsPop4");
  ofstream OutMeanStatistics5("MeanStatsPop5");

  ofstream OutMedianStatistics1("MedianStatsPop1");
  ofstream OutMedianStatistics2("MedianStatsPop2");
  ofstream OutMedianStatistics3("MedianStatsPop3");
  ofstream OutMedianStatistics4("MedianStatsPop4");
  ofstream OutMedianStatistics5("MedianStatsPop5");

  ofstream OutIndividuals("IndivOut");

  ofstream DetailedOutput("OutputDet");

  OutputAll(OutIndividuals);

  GAControl pop1control(GVars.Get_number_of_generations(), GVars.Get_number_alleles(), GVars.Get_number_individuals());
  GAControl pop2control(GVars.Get_number_of_generations(), GVars.Get_number_alleles(), GVars.Get_number_individuals());
  GAControl pop3control(GVars.Get_number_of_generations(), GVars.Get_number_alleles(), GVars.Get_number_individuals());
  GAControl pop4control(GVars.Get_number_of_generations(), GVars.Get_number_alleles(), GVars.Get_number_individuals());
  GAControl pop5control(GVars.Get_number_of_generations(), GVars.Get_number_alleles(), GVars.Get_number_individuals());


  PopulationGenome pop1(GVars.Get_number_alleles(), GVars.Get_number_individuals());
  PopulationGenome pop2(GVars.Get_number_alleles(), GVars.Get_number_individuals());
  PopulationGenome pop3(GVars.Get_number_alleles(), GVars.Get_number_individuals());
  PopulationGenome pop4(GVars.Get_number_alleles(), GVars.Get_number_individuals());
  PopulationGenome pop5(GVars.Get_number_alleles(), GVars.Get_number_individuals());

  //Initialize the "matrix" (actually a vector) for pairs that can fight
  vector<int> Prob_F_Matrix = VectorInit(GVars.Get_ClusterSize(),GVars.Get_number_individuals());


  /** The number of generations between successive
    * file outputs of the genotype of the population
    */
  int gen_stride_total_output = GVars.Get_number_of_generations()/GVars.Get_number_times_total_output();


  // the function pointer that does the fights
  void (*FightAndUpdate) (const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, 
			  const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, 
			  const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, 
			  const double &cost_factor, 
			  const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile);

  if(GVars.Get_type_conflict() == "WA") {
 
  if(GVars.Get_type_cost() == "Simple") FightAndUpdate = FightAndUpdateWA;
  if(GVars.Get_type_cost() == "SizeRatio") FightAndUpdate = FightAndUpdateWASR;
  }

  if (GVars.Get_typeHD()==1) FightAndUpdate = FightAndUpdateHD1;
  if (GVars.Get_typeHD()==2) FightAndUpdate = FightAndUpdateHD2;
  if (GVars.Get_typeHD()==0) FightAndUpdate = FightAndUpdateHD0;


  // Run the GA!
  int current_generation = 1;
  bool output_all = false;


  while(current_generation <= GVars.Get_number_of_generations()) {
    // output of whole genome set (only once in a while)
    if (!(current_generation%gen_stride_total_output) || (current_generation==1)) output_all = true;
    else output_all = false;
    
    // output of summary results (every generation)
    pop1control.SetMeanTraits(current_generation-1, pop1);
    pop1control.OutputFileMeanTraits(OutMeanStatistics1, current_generation-1);
    pop1control.SetMedianQuartileTraits(pop1);
    pop1control.OutputFileMedianQuartileTraits(OutMedianStatistics1);

    pop2control.SetMeanTraits(current_generation-1, pop2);
    pop2control.OutputFileMeanTraits(OutMeanStatistics2, current_generation-1);
    pop2control.SetMedianQuartileTraits(pop2);
    pop2control.OutputFileMedianQuartileTraits(OutMedianStatistics2);

    pop3control.SetMeanTraits(current_generation-1, pop3);
    pop3control.OutputFileMeanTraits(OutMeanStatistics3, current_generation-1);
    pop3control.SetMedianQuartileTraits(pop3);
    pop3control.OutputFileMedianQuartileTraits(OutMedianStatistics3);

    pop4control.SetMeanTraits(current_generation-1, pop4);
    pop4control.OutputFileMeanTraits(OutMeanStatistics4, current_generation-1);
    pop4control.SetMedianQuartileTraits(pop4);
    pop4control.OutputFileMedianQuartileTraits(OutMedianStatistics4);

    pop5control.SetMeanTraits(current_generation-1, pop5);
    pop5control.OutputFileMeanTraits(OutMeanStatistics5, current_generation-1);
    pop5control.SetMedianQuartileTraits(pop5);
    pop5control.OutputFileMedianQuartileTraits(OutMedianStatistics5);

/*
void Within_Generation_Proc(PopulationGenome &g, const std::vector<int> &Prob_F_Matrix, const int &PopulationSize, const double &p_fight,
			    const int &number_periods, const double &p_switch, const int &ClusterSize,const double &fight_cost, 
			    const double &fight_gain, const double &strength_lw_ratio, const double &cost_factor, 
			    const double &strength_gamma_mean, const double &baseline, const int &generation, const bool print_all, 
			    const string &population_name, ofstream &theoutputfile, 
			    void (*FightAndUpdate) (const std::valarray<int>&, const PopulationGenome&, PopulationNonGenome&, 

*/

    // score & fitness
    Within_Generation_Proc(pop1, Prob_F_Matrix,
 					GVars.Get_number_individuals(),GVars.Get_p_fight(), GVars.Get_number_periods(),
    					GVars.Get_p_switch(),GVars.Get_ClusterSize(), 
			   GVars.Get_fight_cost(), GVars.Get_fight_gain(), GVars.Get_strength_lw_ratio(), GVars.Get_RHP_reliability(),
    					GVars.Get_cost_factor(), GVars.Get_strength_gamma_mean(), GVars.Get_baseline(), 
			                current_generation, output_all, "Pop1", OutIndividuals, detail_first, detail_last, DetailedOutput, GVars.Get_typeHD(), FightAndUpdate);


    Within_Generation_Proc(pop2, Prob_F_Matrix,
    					GVars.Get_number_individuals(),GVars.Get_p_fight(), GVars.Get_number_periods(),
    					GVars.Get_p_switch(),GVars.Get_ClusterSize(), 
    					GVars.Get_fight_cost(), GVars.Get_fight_gain(), GVars.Get_strength_lw_ratio(),GVars.Get_RHP_reliability(),
    					GVars.Get_cost_factor(), 
    					GVars.Get_strength_gamma_mean(), GVars.Get_baseline(), current_generation, output_all,
			                "Pop2", OutIndividuals,detail_first, detail_last, DetailedOutput, GVars.Get_typeHD(), FightAndUpdate);

    Within_Generation_Proc(pop3, Prob_F_Matrix,
    					GVars.Get_number_individuals(),GVars.Get_p_fight(), GVars.Get_number_periods(),
    					GVars.Get_p_switch(),GVars.Get_ClusterSize(), 
    					GVars.Get_fight_cost(), GVars.Get_fight_gain(), GVars.Get_strength_lw_ratio(),GVars.Get_RHP_reliability(),
    					GVars.Get_cost_factor(), 
    					GVars.Get_strength_gamma_mean(), GVars.Get_baseline(), current_generation, output_all,
			                "Pop3", OutIndividuals, detail_first, detail_last, DetailedOutput, GVars.Get_typeHD(), FightAndUpdate);

    Within_Generation_Proc(pop4, Prob_F_Matrix,
    					GVars.Get_number_individuals(),GVars.Get_p_fight(), GVars.Get_number_periods(),
    					GVars.Get_p_switch(),GVars.Get_ClusterSize(), 
    					GVars.Get_fight_cost(), GVars.Get_fight_gain(), GVars.Get_strength_lw_ratio(),GVars.Get_RHP_reliability(),
    					GVars.Get_cost_factor(), 
    					GVars.Get_strength_gamma_mean(), GVars.Get_baseline(), current_generation, output_all,
			                "Pop4", OutIndividuals, detail_first, detail_last, DetailedOutput, GVars.Get_typeHD(), FightAndUpdate);

    Within_Generation_Proc(pop5, Prob_F_Matrix,
    					GVars.Get_number_individuals(),GVars.Get_p_fight(), GVars.Get_number_periods(),
    					GVars.Get_p_switch(),GVars.Get_ClusterSize(), 
    					GVars.Get_fight_cost(), GVars.Get_fight_gain(), GVars.Get_strength_lw_ratio(),GVars.Get_RHP_reliability(),
    					GVars.Get_cost_factor(), 
    					GVars.Get_strength_gamma_mean(), GVars.Get_baseline(), current_generation, output_all,
			                "Pop5", OutIndividuals, detail_first, detail_last, DetailedOutput, GVars.Get_typeHD(), FightAndUpdate);

    #ifdef DEBUG
      cout <<"\n RawScore and Fitness \n";
      for (int i=0; i< GVars.Get_number_individuals(); i++) PR(pop1.GetIndividualRawScore(i));
      for (int i=0; i< GVars.Get_number_individuals(); i++) PR(pop1.GetIndividualFitness(i));
    #endif



    // output to screen (also once in a while)    
    if(!(current_generation%20) || (current_generation == 1)) {
      cout << endl;
      cout <<"*** Generation " << current_generation << endl;
	pop1control.ScreenOutMeanTraits(current_generation-1,"Pop1 ");
	pop1.ScreenOutScore();
	pop2control.ScreenOutMeanTraits(current_generation-1,"Pop2 ");
	pop2.ScreenOutScore();
	pop3control.ScreenOutMeanTraits(current_generation-1,"Pop3 ");
	pop3.ScreenOutScore();
	pop4control.ScreenOutMeanTraits(current_generation-1,"Pop4 ");
	pop4.ScreenOutScore();
	pop5control.ScreenOutMeanTraits(current_generation-1,"Pop5 ");
	pop5.ScreenOutScore();
	}


    if(!GVars.Get_OLG()) {
      if(GVars.Get_fitness_type() == "Truncation") {
	pop1.SetFitnessTruncation(GVars.Get_truncation_fraction());
	pop2.SetFitnessTruncation(GVars.Get_truncation_fraction());
	pop3.SetFitnessTruncation(GVars.Get_truncation_fraction());
	pop4.SetFitnessTruncation(GVars.Get_truncation_fraction());
	pop5.SetFitnessTruncation(GVars.Get_truncation_fraction());
      }

      else if(GVars.Get_fitness_type() == "Rank") {
	pop1.SetFitnessRank();
	pop2.SetFitnessRank();
	pop3.SetFitnessRank();
	pop4.SetFitnessRank();
	pop5.SetFitnessRank();
      }


    pop1.Mating();
    pop1.CrossOver(GVars.Get_crossover_probability(), GVars.Get_crossover_type());
    pop1.MutateGenome(GVars.Get_mutation_probability());

    pop2.Mating();
    pop2.CrossOver(GVars.Get_crossover_probability(), GVars.Get_crossover_type());
    pop2.MutateGenome(GVars.Get_mutation_probability());

    pop3.Mating();
    pop3.CrossOver(GVars.Get_crossover_probability(), GVars.Get_crossover_type());
    pop3.MutateGenome(GVars.Get_mutation_probability());

    pop4.Mating();
    pop4.CrossOver(GVars.Get_crossover_probability(), GVars.Get_crossover_type());
    pop4.MutateGenome(GVars.Get_mutation_probability());

    pop5.Mating();
    pop5.CrossOver(GVars.Get_crossover_probability(), GVars.Get_crossover_type());
    pop5.MutateGenome(GVars.Get_mutation_probability());
      }



    else { //i.e., overlapping generations
	pop1.MatingOLG(GVars.Get_OLG_replace_fraction(), GVars.Get_crossover_probability(),GVars.Get_mutation_probability()); 
	pop2.MatingOLG(GVars.Get_OLG_replace_fraction(), GVars.Get_crossover_probability(),GVars.Get_mutation_probability()); 
	pop3.MatingOLG(GVars.Get_OLG_replace_fraction(), GVars.Get_crossover_probability(),GVars.Get_mutation_probability()); 
	pop4.MatingOLG(GVars.Get_OLG_replace_fraction(), GVars.Get_crossover_probability(),GVars.Get_mutation_probability()); 
	pop5.MatingOLG(GVars.Get_OLG_replace_fraction(), GVars.Get_crossover_probability(),GVars.Get_mutation_probability()); 
    }





// Every migration_interval generations, one individual moves from one pop to another;
    if ((current_generation >= GVars.Get_first_migration()) && !(current_generation % GVars.Get_migration_interval())) {
        cout <<"\n Migration events.\n";
	ExchangeChromosomes(pop1, pop2, GVars.Get_number_individuals(), GVars.Get_number_alleles(), current_generation, detail_first, detail_last, DetailedOutput);
	ExchangeChromosomes(pop2, pop3, GVars.Get_number_individuals(), GVars.Get_number_alleles(), current_generation, detail_first, detail_last, DetailedOutput);
	ExchangeChromosomes(pop3, pop4, GVars.Get_number_individuals(), GVars.Get_number_alleles(), current_generation, detail_first, detail_last, DetailedOutput);
	ExchangeChromosomes(pop4, pop5, GVars.Get_number_individuals(), GVars.Get_number_alleles(), current_generation, detail_first, detail_last, DetailedOutput);
	ExchangeChromosomes(pop5, pop1, GVars.Get_number_individuals(), GVars.Get_number_alleles(), current_generation, detail_first, detail_last, DetailedOutput);
    }
    ++current_generation;
}

  //put the parameters into the files, but only on pop1
  GVars.PrintParams(OutMeanStatistics1); 
  GVars.PrintParams(OutMedianStatistics1); 

  double f_mut = static_cast<double>(num_times_mutation) / static_cast<double>(5*GVars.Get_number_alleles() * GVars.Get_number_of_generations() * GVars.Get_number_individuals());

  cout << "\n Mutation freq " << f_mut;

  double deno1 = 5*static_cast<double>(GVars.Get_number_of_generations()) * static_cast<double>(GVars.Get_number_individuals())*static_cast<double>(GVars.Get_number_periods());
  double f_switch = 2*count_num_switchers/deno1;
  double deno2 = 5*static_cast<double>(GVars.Get_number_of_generations())*static_cast<double>(GVars.Get_number_individuals())*static_cast<double>(GVars.Get_number_periods());
  double f_fight = 2*count_num_fighting_pairs/ deno2;

  cout <<"\n n_switchers = "<<2*count_num_switchers<<"  deno1 = "<<deno1;
  cout <<"\n n_fight = "<<2*count_num_fighting_pairs<<"  deno2 = "<<deno2;
 cout << "\n Fight prob "<<f_fight;
 cout <<"\n Switch prob "<<f_switch;
 cout << "\n Number of calls to random number generators "<<random_number_counter;


  OutMeanStatistics1.close();
  OutMedianStatistics1.close();
  //  OutGenotypes1.close();

  OutMeanStatistics2.close();
  OutMedianStatistics2.close();
  //  OutGenotypes2.close();

  OutMeanStatistics3.close();
  OutMedianStatistics3.close();
  //  OutGenotypes3.close();

  OutMeanStatistics4.close();
  OutMedianStatistics4.close();
  //  OutGenotypes4.close();

  OutMeanStatistics5.close();
  OutMedianStatistics5.close();
  //  OutGenotypes5.close();
  OutIndividuals.close();

  DetailedOutput.close();	
  cout << endl;
  return 0;
}




// To do:
// - permitir meter el nombre de los output files 



// Testing:

/************************ COSAS NO TESTADAS AUN **************************************

- Linear Fitness (psss: creo que rula)
- CrossOver: single Point;


****************************************************************************************/
