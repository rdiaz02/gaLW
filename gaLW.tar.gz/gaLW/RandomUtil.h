/***************************************************************************
                          RandomUtil.h  -  description
                             -------------------
    begin                : Mon Dec 4 2000
    copyright            : ? Just a wrapper for random number generators
    email                : ramon-diaz@teleline.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#ifndef RANDOM_UTILITIES_H
#define RANDOM_UTILITIES_H

#include<algorithm>
#include<valarray>
#include<vector>

//#include<blitz/array.h> //Blitz's arrays

#ifdef BL_RANDOM_NUM //if using Blitz's random numbers
#include<random/uniform.h>
#include<random/discrete-uniform.h>
#include<random/normal.h>
#endif

//#ifdef R_RANDOM_NUM //I always have to use R's binomial so this always loaded; but the others can either can come from R or Blitz
#define MATHLIB_STANDALONE
#include <Rmath.h>
//#endif


extern double random_number_counter;

#ifdef BL_RANDOM_NUM
inline double ReturnUniformOpen() {
  ++random_number_counter;
  ranlib::UniformOpen<double> x;
  return x.random();
}

inline double ReturnUniformClosed() {
  ++random_number_counter;
  ranlib::UniformClosed<double> x;
  return x.random();
}

inline unsigned int ReturnDiscreteUniform(unsigned int n) {
//a discrete uniform random number 0,..,n-1
  ++random_number_counter;
  ranlib::DiscreteUniform<int> x(n);
  return x.random();
}

inline double ReturnNormalError(double sd) {
  ++random_number_counter;
  ranlib::Normal<double> x(0,sd);
  return x.random();
}


inline void seed_the_generator(unsigned int the_seed1, unsigned int the_seed2) {
  // seed Blitz's
	using namespace ranlib;
	UniformOpen<float> dummy;
	dummy.seed(the_seed1);
  // seed R's: we aways use R now for, at least, the binomial
	set_seed(the_seed1, the_seed2);
	} //seed the random number generator;

// Note: the generator for R can affect Blitz's: differences in the second
// integer of the R generator can make small differences in the binomial numbers generated;
// if this results, e.g., in a difference in the number of fighting pairs ---which is always
// obtained from R's binomianl RNG---, then we are going to extract a different number
// of uniform RNG from Blitz, thus affecting all subsequent generation of Blitz's random numbers
#endif




#ifdef R_RANDOM_NUM
inline double ReturnUniformOpen() {
    ++random_number_counter;
  return runif(0.00000000000001,0.99999999999999999);
}

inline double ReturnUniformClosed() {
    ++random_number_counter;
  return runif(0,1);
}

inline unsigned int ReturnDiscreteUniform(unsigned int n) {
//a discrete uniform random number 0,..,n-1
    ++random_number_counter;
  return rand() % n;
}

inline void seed_the_generator(unsigned int the_seed, unsigned int the_seed2) {
  set_seed(the_seed, the_seed2);
	} 


inline double ReturnNormalError(double sd) {
    ++random_number_counter;
   return rnorm(0, sd);
  }


//seed the random number generator;
#endif




template <class Ran>
inline void random_shuffle_2(Ran first, Ran last) {
  // copied from stl_algo.h, but I modify the call to the random number
  // generator to have control over it
  if (first == last) return;
  for (Ran i = first + 1; i != last; ++i)
    iter_swap(i, first + ReturnDiscreteUniform((i - first) + 1));
}



/** 
 * For sampling ONE element with probability
 * given by VectorProbs, a vector of probabilities.
 * Will return the index of the vector sampled
 */


inline unsigned int Prob_Sampling_Index(const valarray<double>& VectorProbs)
{
    double random = ReturnUniformClosed();
    double mass = 0;
    unsigned int i = 0;
    for(i = 0; i < VectorProbs.size() ; i++){
      mass += VectorProbs[i];
      if(random <= mass) break;
    }
    return i;
}


/* These are no longer used; were used in the selection of fighting pairs, but not
anymore; still, I leave them here just in case

inline int Prob_Sampling_Index(const blitz::Array<double,1>& VectorProbs)
{
    double random = ReturnUniformClosed();
    double mass = 0.0;
    int i = 0;
    for(i = 0; i < VectorProbs.size() ; i++){
	mass += VectorProbs(i); 
	if(random <= mass) break;
    }
    return i;
}


inline void Sampling_Prob_F_Matrix(const blitz::Array<double,2>& the_p_matrix, const int &population_size, int &i1, int &i2)
{
    double random = ReturnUniformClosed();
    double mass = 0.0;
    int i = 0;
    int j = 0;
    for(i = 0; i < population_size; i++){
      for (j = i+1; j < population_size; j++) {
	  mass += the_p_matrix(i,j);
	  if (random <= mass) goto found; 
      }
    }
    found:
    i1 = i;
    i2 = j;
}


inline void Sampling_Special_Prob_F_Matrix(const blitz::Array<double,2>& the_p_matrix, const int &population_size, int &i1, int &i2, const int &ClusterSize)
{
    double random = ReturnUniformClosed();
    double mass = 0.0;
    int i = 0;
    int j = 0;
    for(i = 0; i < population_size; i++){
      for (j = i+1; j < ((i/ClusterSize) * ClusterSize) + ClusterSize; j++) {
	  mass += the_p_matrix(i,j);
	  if (random <= mass) goto found; 
      }
    }
    found:
    i1 = i;
    i2 = j;
}

*/


#endif //define RANDOM_UTILITIES_H





