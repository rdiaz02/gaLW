/***************************************************************************
                          fighting.cpp  -  description
                             -------------------
    begin                : Tue Nov 28 2000
    copyright            : (C) 2000, 2004 by Ram�n D�az-Uriarte
    email                : rdiaz@ligarto.org
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// See file ChosseFightingPairs.cc for original, plus other code for output;
// I first wrote the "choose_fighing_pairs used here in pairs-test-5h5.cc.
// This function was being a major time sink of the problem. The way fighters are selected now
// is very different from the original.
// Now, the probability within cluster is always 1. Thus, all the pairs that can be choosen
// can be choosen with the same probability. Therefore, we don't really need a matrix, but
// only a vector, and we choose a pair by randomly selecting an index of this vector.  This is
// a lot faster than looping over the matrix, even when the matrix is only upper-triangular (as
// in pairs-test-5n.cc).
// This vector contains the index of the matrix position; I only use also upper triangulars,
// to cut down time and space. We can go from the index to the row by index/PopulationSize (integer division)
// and to column by index%PopulationSize;
// After selecting the index, we need to eliminate all indeces that relate to those individuals (row and
// and column); this is a little bit cumbersome, but still faster than looping over the array.
// When cluster size is 2, it is a lot, lot faster.




extern double count_num_fighting_pairs, count_num_switchers; //to count, to double check things OK in fighting paris and switchers

#include<algorithm>
#include<valarray>
#include<iostream>
//#include<blitz/array.h> //Blitz's arrays

#include<string>
#include<cmath>

#include"ga.h" //the declaration of the PopulationGenome class and member functions
#include"RandomUtil.h"

#define MATHLIB_STANDALONE   //We always use R, for the binomial random number generator
#include <Rmath.h>


#ifdef BL_RANDOM_NUM //are we using Blitz's random numbers?
#include<random/gamma.h> // then use Blitz's gamma random variate generator
#endif

#undef DEBUG
//#define DEBUG
#ifdef DEBUG
#define PR(x) cout << #x " = " << x << '\n';
#endif

extern double random_number_counter;

/////////////////////// Declarations /////////////////////////////////


// holds the non-genomic variables
class PopulationNonGenome {
  int population_size;
  valarray<double> Strength;
  valarray<double> LState;
  valarray<double> WState;
  valarray<double> PartialScore; //here we store the gain-cost
  valarray<int> Num_won;
  valarray<int> Num_lost;
  //  valarray<int> LastWon;
  valarray<int> LastFight;
public:
  PopulationNonGenome(const int pop_size, const double strength_mean);
  void SetPartialScore(const int individual, const double& new_score) {PartialScore[individual] += new_score;}
  void SetLState(const int individual, const double& lstate) {LState[individual] = lstate;}
  void SetWState(const int individual, const double& wstate) {WState[individual] = wstate;}
  void SetLastFight(const int individual, const int period) {LastFight[individual] = period;}
  //  void SetLastWon(const int individual, const int period) {LastWon[individual] = period;}
  void Num_wonIncrease(const int individual) {++Num_won[individual];}
  void Num_lostIncrease(const int individual) {++Num_lost[individual];}
  double GetPartialScore(const int individual) const {return PartialScore[individual];}
  double GetStrength(const int individual) const {return Strength[individual];}
  double GetLState(const int individual) const {return LState[individual];}
  double GetWState(const int individual) const {return WState[individual];}
  int GetNum_won(const int individual) const {return Num_won[individual];}
  int GetNum_lost(const int individual) const {return Num_lost[individual];}
  int GetLastFight(const int individual) const {return LastFight[individual];}
  //  int GetLastWon(const int individual) const {return LastWon[individual];}
};


// update the Loser and Winner states if they are not current
inline void UpdateLW(const int &indiv, const PopulationGenome &g, PopulationNonGenome &p, const int current_period) {
  if((current_period - p.GetLastFight(indiv))>1) {
    p.SetLState(indiv, pow(g.GetGene(indiv, 1), static_cast<double>((current_period - (p.GetLastFight(indiv) + 1)))) * p.GetLState(indiv));
    p.SetWState(indiv, pow(g.GetGene(indiv, 2), static_cast<double>((current_period - (p.GetLastFight(indiv) + 1)))) * p.GetWState(indiv));
    p.SetLastFight(indiv, current_period-1);
  }

  //  if((current_period - p.GetLastLost(indiv)) > 1) {
  // p.SetLState(indiv, pow(g.GetGene(indiv, 1), static_cast<double>((current_period - (p.GetLastLost(indiv) + 1)))) * p.GetLState(indiv));
  // p.SetLastLost(indiv, current_period-1); //i.e., like it had been evaluated or involved in a fight in the last period;
    //makes no difference for this funct. or for EvaluateLW but it would make a difference because
    //the value is stored, and LastLost might not be updated later in FIghtAndUpdate if this individual wins
  // }
  //if((current_period - p.GetLastWon(indiv)) > 1) {
  //   p.SetWState(indiv, pow(g.GetGene(indiv, 2), static_cast<double>((current_period - (p.GetLastWon(indiv) + 1)))) * p.GetWState(indiv));
  //   p.SetLastWon(indiv, current_period-1);
  // }
}


// the following three are called from within FightAndUpdate; CAREFUL: they assume the LW state has been updated;
// you can call UpdateLW if in doubt.
inline double EvaluateLW(const int &individual, const PopulationGenome &g, const PopulationNonGenome &p, const double &baseline) {
    double tmp =  g.GetGene(individual, 0) + (g.GetGene(individual,3) * p.GetLState(individual)) + (g.GetGene(individual,4) * p.GetWState(individual));
    if (tmp < 0.0) return 0.0; else return tmp;  //chop
    //    return tmp;
  }

inline double NewLState(const int &individual, const PopulationGenome &g, const PopulationNonGenome &p, const int &newv) {
    return (1.0- g.GetGene(individual, 1)) * static_cast<double> (newv) + g.GetGene(individual, 1) * p.GetLState(individual);
  }

inline double NewWState(const int &individual, const PopulationGenome &g, const PopulationNonGenome &p, const int &newv) {
    return (1.0- g.GetGene(individual, 2)) * static_cast<double> (newv) + g.GetGene(individual, 2) * p.GetWState(individual);
  }


inline double EvaluateLW_HD1(const int &individual, const PopulationGenome &g, const PopulationNonGenome &p) {
    double tmp =  g.GetGene(individual,0) + (g.GetGene(individual,3) * p.GetLState(individual)) + (g.GetGene(individual,4) * p.GetWState(individual));
    if (tmp < 0.0) tmp = 0.0;  //chop
    if (tmp > 1.0) tmp = 1.0;  //chop
    return tmp;
  }


inline double EvaluateLW_HD2(const int &individual, const PopulationGenome &g, const PopulationNonGenome &p) {
    double tmp =  exp(g.GetGene(individual,0) + (g.GetGene(individual,3) * p.GetLState(individual)) + (g.GetGene(individual,4) * p.GetWState(individual)));
    return tmp/(1+tmp);
    return tmp;
  }


inline double EvaluateLW_HD0(const int &individual, const PopulationGenome &g, const PopulationNonGenome &p) {
  return g.GetGene(individual,0);
  }


inline void DetailedOutputB(const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile, const PopulationGenome &g, const PopulationNonGenome &p, const int indiv1, const int indiv2, const int winner, const int loser) {
 if ((generation >= detail_first) && (generation <= detail_last)) {
     thedetailedfile <<"\n \n After the fight \n";
     thedetailedfile<<"\n indiv1 "<<indiv1<<" indiv2 "<<indiv2 <<". Winner " <<winner <<'\n';
     thedetailedfile<<"\n Phenotype "<<indiv1<<"   " <<p.GetStrength(indiv1)<<"   " <<p.GetLState(indiv1) <<"   "
		    <<p.GetWState(indiv1) <<"   "<<p.GetPartialScore(indiv1);
     thedetailedfile<<"\n Phenotype "<<indiv2<<"   " <<p.GetStrength(indiv2)<<"   " <<p.GetLState(indiv2) <<"   "
		    <<p.GetWState(indiv2) <<"   "<<p.GetPartialScore(indiv2);
 }
}

inline void DetailedOutputA(const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile, const PopulationGenome &g, const PopulationNonGenome &p, const int indiv1, const int indiv2, const double LW1, const double LW2, const int period) {
 if ((generation >= detail_first) && (generation <= detail_last)) {
   thedetailedfile <<"\n \n \n *******Before the fight.  Period is "<< period <<'\n';
     thedetailedfile<<"\n indiv1 "<<indiv1<<" indiv2 "<<indiv2 <<'\n';
     thedetailedfile<<"\n Phenotype "<<indiv1<<"    " <<p.GetStrength(indiv1)<<"    " <<p.GetLState(indiv1) <<"    "
		    <<p.GetWState(indiv1) <<"    "<<p.GetPartialScore(indiv1) <<" LW1 " <<LW1;
     thedetailedfile<<"\n Phenotype "<<indiv2<<"    " <<p.GetStrength(indiv2)<<"    " <<p.GetLState(indiv2) <<"    "
		    <<p.GetWState(indiv2) <<"    "<<p.GetPartialScore(indiv2) <<" LW2 "<< LW2;
 }
}




// This does the fights, updates loser/winner state and outputs a temporary store for the score
/*
void FightAndUpdate(valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &cost_factor, const std::string &type_conflict, const std::string &type_cost, const double &baseline, const int period);
*/




// Extracts the pairs that will fight in each period, and then does the fights (calling FightAndUpdate);
// iterates the process for all the periods within a generation

void Within_Generation_Proc(PopulationGenome &g, const std::vector<int> &Prob_F_Matrix, const int &PopulationSize, 
			    const double &p_fight, const int &number_periods, const double &p_switch, const int &ClusterSize, 
			    const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability,
			    const double &cost_factor, const double &strength_gamma_mean, const double &baseline, 
			    const int &generation, const bool output_all, const string &population_name, ofstream &theoutputfile,
			    const int detail_first, const int detail_last, ofstream &thedetailedfile, const int &type_HD, 
			    void (*FightAndUpdate) (const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile));

//for explanation of why the pointer to function, see main.cpp.



// The following three are used in operations with the matrix that holds the prob. of fights.
void Update_Matrix_ID_Table(const int& size_population, const int& number_switchers, valarray<int>& Matrix_to_ID);
//void Update_Matrix_ID_Table(const int& size_population, const int& number_switchers, vector<int>& Matrix_to_ID);

vector<int> VectorInit(const int ClusterSize, const int PopulationSize);

void Choose_Fighting_Pairs(valarray<int> &Matrix_Fighting_Pairs, const std::vector<int> &Prob_F_Matrix,  const int &number_fighting_pairs, const int &population_size, const int &ClusterSize);


void OutputAll(ofstream &thefile);

void OutputAll(const PopulationGenome &g, PopulationNonGenome &p, ofstream &thefile, const int &generation, const string &s1, const double &baseline,const int &PopulationSize, const int period, const int type_HD);

/////////////////////////////////  Definitions /////////////////////////////////////////////////


PopulationNonGenome::PopulationNonGenome(const int pop_size, const double strength_mean){
  population_size = pop_size;
  Strength.resize(pop_size);
  LState.resize(pop_size);
  WState.resize(pop_size);
  PartialScore.resize(pop_size);
  Num_won.resize(pop_size);
  Num_lost.resize(pop_size);
  LastFight.resize(pop_size);
  //  LastWon.resize(pop_size);
  LState = 0.0;
  WState = 0.0;
  PartialScore = 0.0;
  Num_won = 0;
  Num_lost = 0;
  LastFight= 0;
  //LastWon = 0;
  #ifdef BL_RANDOM_NUM
  ranlib::Gamma<double> x(strength_mean);
  for (int i=0; i<population_size; i++) { 
    ++random_number_counter;
    Strength[i]=x.random();  
  }
  #endif
  
  #ifdef R_RANDOM_NUM
  for (int i=0; i<population_size; i++) {
    ++random_number_counter;
    Strength[i]=rgamma(strength_mean, 1);  
  }
  #endif
}



void Within_Generation_Proc(PopulationGenome &g, const std::vector<int> &Prob_F_Matrix, const int &PopulationSize, 
			    const double &p_fight, const int &number_periods, const double &p_switch, const int &ClusterSize, 
			    const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability,
			    const double &cost_factor, const double &strength_gamma_mean, const double &baseline, 
			    const int &generation, const bool output_all, const string &population_name, ofstream &theoutputfile,
			    const int detail_first, const int detail_last, ofstream &thedetailedfile, const int &type_HD, 
			    void (*FightAndUpdate) (const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile)){


 PopulationNonGenome NoGenome(PopulationSize, strength_gamma_mean); //The nongenomic vars can be different each generation, but are the same within generation

 /* commented out for speed 
 if ((generation >= detail_first) && (generation <= detail_last)) {
   thedetailedfile <<"\n *********************GENERATION "<<generation;
   thedetailedfile << "\n Population "<<population_name;
   thedetailedfile<<"\n The genotype \n";
   for(int i = 0; i < PopulationSize; i++) {
     thedetailedfile << " Individual " << i <<" ";
     for(int k = 0; k<5; k++) thedetailedfile <<g.GetGene(i,k) << " ";
     thedetailedfile<<'\n';
   }
   thedetailedfile<<"\n";
   thedetailedfile <<"\n The initial phenotype \n"; 
   for (int i=0; i< PopulationSize; i++) thedetailedfile <<" Individual " << i <<" strength "<<NoGenome.GetStrength(i)<<'\n';
 }
 */


  valarray<int> Matrix_to_ID(PopulationSize);
// vector<int> Matrix_to_ID(PopulationSize);
 for(int mm = 0; mm < PopulationSize; mm++) Matrix_to_ID[mm] = mm;
 random_shuffle_2(&Matrix_to_ID[0], &Matrix_to_ID[PopulationSize]); //shuffle to begin with

 int g_p = 1; //stands for "withing generation period" but that was too long
 for (g_p = 1; g_p <= number_periods; g_p++) {// this is within each period of each generation

   // allow for individuals to switch clusters; conceptually, happens at end of period, but doing it here is equivalent
 int num_switchers = static_cast<int>(rint(rbinom(PopulationSize, p_switch)/2));
 count_num_switchers += num_switchers;


 if(num_switchers) Update_Matrix_ID_Table(PopulationSize, num_switchers, Matrix_to_ID);


 int number_fighting_pairs = static_cast<int>(rint(rbinom(PopulationSize, p_fight)/2));

 count_num_fighting_pairs += number_fighting_pairs;

 if (number_fighting_pairs) { // only if anybody fights
     valarray<int> Matrix_Fighting_Pairs(2*number_fighting_pairs);
     valarray<int> Fighting_Pairs(2*number_fighting_pairs);
     Choose_Fighting_Pairs(Matrix_Fighting_Pairs, Prob_F_Matrix, number_fighting_pairs, PopulationSize, ClusterSize);
 
    //convert the matrix id's into indiv. id's by using Matrix_to_ID table
     for (int ii = 0; ii < 2*number_fighting_pairs; ii++) Fighting_Pairs[ii] = Matrix_to_ID[Matrix_Fighting_Pairs[ii]];

     //do fighting and changes in L/W state
     FightAndUpdate(Fighting_Pairs, g, NoGenome, PopulationSize, number_fighting_pairs, fight_cost, fight_gain, strength_lw_ratio, 
		  RHP_reliability, cost_factor, baseline, g_p, detail_first, detail_last, generation, thedetailedfile);

 }
 }

 if(output_all) OutputAll(g, NoGenome, theoutputfile, generation, population_name, baseline, PopulationSize, number_periods, type_HD);
 for (int i = 0; i < PopulationSize; i++) g.SetIndividualRawScore(i, NoGenome.GetPartialScore(i));

 /* commented out for speed
 if((generation >= detail_first) && (generation <= detail_last)) {
   thedetailedfile <<"\n \n The final phenotype \n"; 
   for (int i=0; i< PopulationSize; i++) thedetailedfile <<" Individual " << i <<" strength "<<NoGenome.GetStrength(i)
							 <<" LState " <<NoGenome.GetLState(i) <<" WState "<<NoGenome.GetWState(i)
							 <<" Num_won "<<NoGenome.GetNum_won(i) <<" Num_lost "<<NoGenome.GetNum_lost(i) 
							 <<" Num fought " << NoGenome.GetNum_won(i) + NoGenome.GetNum_lost(i) 
							 <<" Score "<<NoGenome.GetPartialScore(i)<<'\n';
 }
 */

}


// seems slightly faster using valarray than vector
void Update_Matrix_ID_Table(const int& size_population, const int& number_switchers, 
			    valarray<int>& Matrix_to_ID) {
  valarray<int> tmp = Matrix_to_ID;
  random_shuffle_2(&tmp[0], &tmp[size_population]);
  for(int i=0; i < number_switchers-1; i+=2) 
    iter_swap(&Matrix_to_ID[tmp[i]], &Matrix_to_ID[tmp[i+1]]);
}

/*
void Update_Matrix_ID_Table(const int& size_population, const int& number_switchers, 
			    vector<int>& Matrix_to_ID) {
  vector<int> tmp = Matrix_to_ID;
  random_shuffle_2(&tmp[0], &tmp[size_population]);
  for(int i=0; i < number_switchers-1; i+=2) 
    iter_swap(&Matrix_to_ID[tmp[i]], &Matrix_to_ID[tmp[i+1]]);
}
*/




void Choose_Fighting_Pairs(valarray<int> &Matrix_Fighting_Pairs, const vector<int> &VectorIndivs, const int &number_fighting_pairs, const int &PopulationSize, const int &ClusterSize) {
   vector<int> v = VectorIndivs;
   int num_fighter = 0;

   for(;;){

   // select the fighting pair
       int random_num = ReturnDiscreteUniform(v.size());
   int ChoosenIndex = v[random_num];
   int i1 = ChoosenIndex / PopulationSize;
   int i2 = ChoosenIndex % PopulationSize;

    Matrix_Fighting_Pairs[num_fighter] = i1;
    Matrix_Fighting_Pairs[++num_fighter] = i2;

    ++num_fighter;

    if(num_fighter == 2*number_fighting_pairs) break;


   //eliminate elements from the vector of individuals
    if(ClusterSize == 2) v.erase(v.begin()+random_num); // we only need to delete the element we just extracted
    else { //i.e., ClusterSizes > 2; here we need to eliminate any element where the selected individuals show up
    vector<int> ToEliminate0((PopulationSize/ClusterSize) * (ClusterSize * (ClusterSize -1 ) /2)+2, 99999999); //make it large enough and fill it with garbage we can later recognize;
 
   int i = 0;
   // row of i1:
   for (int j = i1+1; j <((i1/ClusterSize) * ClusterSize) + ClusterSize; j++, i++) ToEliminate0[i] = (i1 * PopulationSize) + j;
   //row of i2:
   for (int j = i2+1; j <((i2/ClusterSize) * ClusterSize) + ClusterSize; j++, i++) ToEliminate0[i] = (i2 * PopulationSize) + j;
   //column of i1:
   for(int j = (i1/ClusterSize) * ClusterSize; j < i1; j++, i++) ToEliminate0[i] = (j * PopulationSize) + i1; 
   //column of i2:
   for(int j = (i2/ClusterSize) * ClusterSize; j < i2; j++, i++) ToEliminate0[i] = (j * PopulationSize) + i2; 

   // give it its final size
   vector<int> ToEliminate(ToEliminate0.begin(), find(ToEliminate0.begin(), ToEliminate0.end(),99999999)); 

   //eliminate duplicated elements; Stroustrup, p. 534. I do this to minimize time in the loops below. //xx:optim: is it worth it?
   sort(ToEliminate.begin(), ToEliminate.end());
   vector<int>::iterator p_for_erase=unique(ToEliminate.begin(), ToEliminate.end());
   ToEliminate.erase(p_for_erase, ToEliminate.end());

   //now eliminate the elements that need to be eliminated
   vector<int> v1tmp(v.size(), -9);
   int j = 0;
   for (unsigned int ii = 0; ii < v.size(); ii++) {
     if(find(ToEliminate.begin(), ToEliminate.end(),v[ii]) == ToEliminate.end()) {
       v1tmp[j] = v[ii];
       ++j;
     }
   }

   //resize v1tmp (excluding the -9), and assign to v1
   v1tmp.erase(find(v1tmp.begin(), v1tmp.end(), -9),v1tmp.end());
   v.resize(v1tmp.size());
   v = v1tmp;
    } //else ---clustersize>2
   } //for(;;)
   if(v.size()==0) {
     cout <<"\n *******THE FUNNY ERROR **************";
     cout << "\n Here you have that special case:";
     cout << "\n you have choosen more pairs than you can have with this cluster size and pnofight;";
     cout <<"\n you probably have an odd cluster size and pnofight of 0.";
     cout <<"\n I am bailing out. \n";
     exit(1);
   } 
}



void OutputAll(ofstream &thefile) {
  // print out the variable names to the file
  thefile<<"Generation\tPopulation\tIndividual\tgene1\tgene2\tgene3\tgene4\tgene5\tstrength\tLW\tLState\tWState\tScore\tNumWon\tNumLost\n";
}

void OutputAll(const PopulationGenome &g, PopulationNonGenome &p, ofstream &thefile, const int &generation, const string &s1, const double &baseline,const int &PopulationSize, const int period, const int type_HD) {
  for (int i = 0; i < PopulationSize; i++) {
    //first, update LW state, since EvaluateLW, GetLstate and GetWstate depend on it to give meaningful output
    UpdateLW(i, g, p, period+1);
    thefile << generation << '\t' << s1 << '\t';
    thefile << i << '\t';
    for (int j = 0; j < 5; j++) thefile << g.GetGene(i, j) << '\t';
    thefile<< p.GetStrength(i) << '\t';
      if((type_HD ==1) || (type_HD==0)) thefile<<EvaluateLW_HD0(i, g, p); else thefile<<EvaluateLW(i, g, p, baseline);
      thefile << '\t' << p.GetLState(i) << '\t' << p.GetWState(i) <<
      '\t' << p.GetPartialScore(i) << '\t' << p.GetNum_won(i) << '\t' << p.GetNum_lost(i) << '\n'; //xx:ojo, aniadir Evaluate con LW_HD2

  }
}


vector<int> VectorInit(const int ClusterSize, const int PopulationSize) {
  // number of clusters * elements in upper diagonal of each cluster
  int num_elements = (PopulationSize/ClusterSize) * (ClusterSize * (ClusterSize -1 ) /2); 
  vector<int> v(num_elements);
  int m = 0;
  for (int i = 0; i < PopulationSize; i ++ ) {
    for (int j = i + 1; j < ((i/ClusterSize) * ClusterSize) + ClusterSize; j++) {
      v[m] = (i * PopulationSize) + j;
      ++m;
    }
  }
  return v;
}


// fight and update for Hawk-Dove, with simple probability addition and chopping
void FightAndUpdateHD1(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile) {

    int ii = 0;
    while (ii < 2*number_fighting_pairs) { // do this for every pair of fighters
	//evaluate LW state
	int indiv1 = FightingPairs[ii];
	int indiv2 = FightingPairs[ii+1];
	UpdateLW(indiv1, g, p, period);
	UpdateLW(indiv2, g, p, period);

	double LW1, LW2;
	LW1 = EvaluateLW_HD1(indiv1, g, p);
	LW2 = EvaluateLW_HD1(indiv2, g, p);


	//who fights?
	int first_fights = 0;
	int second_fights = 0;
	if (LW1>= ReturnUniformClosed()) first_fights = 1;
	if (LW2>= ReturnUniformClosed()) second_fights = 1;


        //who wins?; then, set score
	int winner = -9;
	int loser = -9;

	if(first_fights==0 && second_fights==0) {//both non-scalators; see Maynard-Smith, p.22 and Hammerstein, 1981, M4 and M5.
	  if(0.5 >= ReturnUniformClosed()) {
	    winner = indiv1;
	    loser = indiv2;
	  }
	  else {
	    winner = indiv2;
	    loser = indiv1;
	  }
	  p.SetPartialScore(winner, fight_gain);
	}

	else if(first_fights == 0 && second_fights==1) {
	  winner = indiv2;
	  loser = indiv1;
	  p.SetPartialScore(winner, fight_gain);
	}

	else if(first_fights == 1 && second_fights == 0) {
	  winner = indiv1;
	  loser = indiv2;
	  p.SetPartialScore(winner, fight_gain);
	}

  	else { //if(first_fights == 1 && second_fights==1)
	    long double tmp1 = exp((RHP_reliability*(p.GetStrength(indiv1) - p.GetStrength(indiv2))));
	    long double p1win = tmp1/(1+tmp1);
	    if(p1win >= ReturnUniformClosed()) { 
	      winner = indiv1;
	      loser = indiv2;
	    }
	    else {
	      winner = indiv2;
	      loser = indiv1;
	    }
	    p.SetPartialScore(winner,fight_gain);
	    p.SetPartialScore(loser, -(fight_cost));
	}
	
	// update winner and loser states, lastfight and number won and lost
	p.SetWState(winner, NewWState(winner, g, p, 1));
	p.SetWState(loser, NewWState(loser, g, p, 0));
	p.SetLState(loser, NewLState(loser, g, p, 1));
	p.SetLState(winner, NewLState(winner, g, p, 0));

	p.SetLastFight(winner, period);
	p.SetLastFight(loser, period);
	
	p.Num_wonIncrease(winner);
	p.Num_lostIncrease(loser);
	
    	ii+=2;
    }
}
    



void FightAndUpdateHD2(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile) {

    int ii = 0;
    while (ii < 2*number_fighting_pairs) { // do this for every pair of fighters
	//evaluate LW state
	int indiv1 = FightingPairs[ii];
	int indiv2 = FightingPairs[ii+1];
	UpdateLW(indiv1, g, p, period);
	UpdateLW(indiv2, g, p, period);

	double LW1, LW2;
	LW1 = EvaluateLW_HD2(indiv1, g, p);
	LW2 = EvaluateLW_HD2(indiv2, g, p);


	//who fights?
	int first_fights = 0;
	int second_fights = 0;
	if (LW1>= ReturnUniformClosed()) first_fights = 1;
	if (LW2>= ReturnUniformClosed()) second_fights = 1;


        //who wins?; then, set score
	int winner = -9;
	int loser = -9;

	if(first_fights==0 && second_fights==0) {//both non-scalators; see Maynard-Smith, p.22 and Hammerstein, 1981, M4 and M5.
	  if(0.5 >= ReturnUniformClosed()) {
	    winner = indiv1;
	    loser = indiv2;
	  }
	  else {
	    winner = indiv2;
	    loser = indiv1;
	  }
	  p.SetPartialScore(winner, fight_gain);
	}

	else if(first_fights == 0 && second_fights==1) {
	  winner = indiv2;
	  loser = indiv1;
	  p.SetPartialScore(winner, fight_gain);
	}

	else if(first_fights == 1 && second_fights == 0) {
	  winner = indiv1;
	  loser = indiv2;
	  p.SetPartialScore(winner, fight_gain);
	}

  	else { //if(first_fights == 1 && second_fights==1)
	    long double tmp1 = exp((RHP_reliability*(p.GetStrength(indiv1) - p.GetStrength(indiv2))));
	    long double p1win = tmp1/(1+tmp1);
	    if(p1win >= ReturnUniformClosed()) { 
	      winner = indiv1;
	      loser = indiv2;
	    }
	    else {
	      winner = indiv2;
	      loser = indiv1;
	    }
	    p.SetPartialScore(winner,fight_gain);
	    p.SetPartialScore(loser, -(fight_cost));
	}
	
	// update winner and loser states, lastfight and number won and lost
	p.SetWState(winner, NewWState(winner, g, p, 1));
	p.SetWState(loser, NewWState(loser, g, p, 0));
	p.SetLState(loser, NewLState(loser, g, p, 1));
	p.SetLState(winner, NewLState(winner, g, p, 0));

	p.SetLastFight(winner, period);
	p.SetLastFight(loser, period);
	
	p.Num_wonIncrease(winner);
	p.Num_lostIncrease(loser);
	
    	ii+=2;
    }
}
    


void FightAndUpdateHD0(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile) {

    int ii = 0;
    while (ii < 2*number_fighting_pairs) { // do this for every pair of fighters
	//evaluate LW state
	int indiv1 = FightingPairs[ii];
	int indiv2 = FightingPairs[ii+1];
	UpdateLW(indiv1, g, p, period);
	UpdateLW(indiv2, g, p, period);

	double LW1, LW2;
	LW1 = EvaluateLW_HD0(indiv1, g, p);
	LW2 = EvaluateLW_HD0(indiv2, g, p);


	//who fights?
	int first_fights = 0;
	int second_fights = 0;
	if (LW1>= ReturnUniformClosed()) first_fights = 1;
	if (LW2>= ReturnUniformClosed()) second_fights = 1;


        //who wins?; then, set score
	int winner = -9;
	int loser = -9;

	if(first_fights==0 && second_fights==0) {//both non-scalators; see Maynard-Smith, p.22 and Hammerstein, 1981, M4 and M5.
	  if(0.5 >= ReturnUniformClosed()) {
	    winner = indiv1;
	    loser = indiv2;
	  }
	  else {
	    winner = indiv2;
	    loser = indiv1;
	  }
	  p.SetPartialScore(winner, fight_gain);
	}

	else if(first_fights == 0 && second_fights==1) {
	  winner = indiv2;
	  loser = indiv1;
	  p.SetPartialScore(winner, fight_gain);
	}

	else if(first_fights == 1 && second_fights == 0) {
	  winner = indiv1;
	  loser = indiv2;
	  p.SetPartialScore(winner, fight_gain);
	}

  	else { //if(first_fights == 1 && second_fights==1)
	    if(0.5 >= ReturnUniformClosed()) { 
	      winner = indiv1;
	      loser = indiv2;
	    }
	    else {
	      winner = indiv2;
	      loser = indiv1;
	    }
	    p.SetPartialScore(winner,fight_gain);
	    p.SetPartialScore(loser, -(fight_cost));
	}
	
	// update winner and loser states, lastfight and number won and lost
	p.SetWState(winner, NewWState(winner, g, p, 1));
	p.SetWState(loser, NewWState(loser, g, p, 0));
	p.SetLState(loser, NewLState(loser, g, p, 1));
	p.SetLState(winner, NewLState(winner, g, p, 0));

	p.SetLastFight(winner, period);
	p.SetLastFight(loser, period);
	
	p.Num_wonIncrease(winner);
	p.Num_lostIncrease(loser);
	
    	ii+=2;
    }
}
    





// fight and update for War of attrition
void FightAndUpdateWA(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile) {

    int ii = 0;
    while (ii < 2*number_fighting_pairs) { // do this for every pair of fighters
	//evaluate LW state
	int indiv1 = FightingPairs[ii];
	int indiv2 = FightingPairs[ii+1];
	UpdateLW(indiv1, g, p, period);
	UpdateLW(indiv2, g, p, period);

	// interpret LW1 and LW2 como los giving-up thresholds
	double LW1, LW2;
	LW1 = EvaluateLW(indiv1, g, p, baseline);
	LW2 = EvaluateLW(indiv2, g, p, baseline);


	int winner = -999; //if not properly assigned, program will blow-up;
	int loser = -999; // a brute check against having duration1==duration2 below

	// DetailedOutputA(detail_first, detail_last, generation, thedetailedfile, g, p, indiv1, indiv2, LW1, LW2, period); commented out for speed


// the logic below: try to minimize potentially expensive computations and generation of random variates;
// first check if one of the has LW ==0.0; if so, no need to obtain a random variate for strength, etc.
// we do: is LW1 ==0.0? if it is, either 2 wins (LW2 >0) or both are zero;
// if LW1 is NOT zero, then either 1 wins (LW2 == 0) without doubt or both have LW>0;
// in the latter case, need to do more expensive calculations.

	if(LW1 == 0.0) {
	    if(LW2 > 0.0) {
		winner = indiv2;
		loser = indiv1;
		p.SetPartialScore(winner, fight_gain); //we don't have SetPartialScore for loser, since we would just add 0.0
	    }
	    else { // both are 0. so we decide winner randomly
		if(0.5 >= ReturnUniformClosed()) {
		    winner = indiv1;
		    loser = indiv2;
		    p.SetPartialScore(winner, fight_gain);
		}
		else {
		    winner = indiv2;
		    loser = indiv1;
		    p.SetPartialScore(winner, fight_gain);
		}
	    } //when both are 0
	} //LW1==0.0
	else if(LW2 == 0) { //indiv1 must be the winner
	  winner = indiv1;
	  loser = indiv2;
	  p.SetPartialScore(winner, fight_gain);
	}
	else { //neither LW1 nor LW2 are 0.0
	// real_s1 and real_s2 are the "truly observed" strenghts of each individual in that particular fight;
	// thus, this is a model where each individual's strength might deviate from the nominal one by a random amount
	    double real_s1 = p.GetStrength(indiv1) * exp(ReturnNormalError(1/RHP_reliability)); 
	    double real_s2 = p.GetStrength(indiv2) * exp(ReturnNormalError(1/RHP_reliability)); 

	    double duration1 = LW1*real_s1*real_s1;
	    double duration2 = LW2*real_s2*real_s2;
	//	if((LW1*pow(real_s1,2)) > (LW2*pow(real_s2,2))) {
	    if(duration1 > duration2) {
		winner = indiv1;
		loser = indiv2;
		//	  p.SetPartialScore(winner, fight_gain-(LW2 * pow(real_s2,2)/pow(real_s1,2)));
		p.SetPartialScore(winner, fight_gain-(duration2/(real_s1*real_s1)));
		p.SetPartialScore(loser,-LW2);
	    }
	    
	    //	    else if (duration1 < duration2){
	    else{
		winner = indiv2;
		loser = indiv1;
		//	  p.SetPartialScore(winner, fight_gain-(LW1 * pow(real_s1,2)/pow(real_s2,2)));
		p.SetPartialScore(winner, fight_gain-(duration1/(real_s2*real_s2)));
		p.SetPartialScore(loser,-LW1);
	    }
	}// both LW1 and LW2 are > 0

	p.SetWState(winner, NewWState(winner, g, p, 1));
	p.SetWState(loser, NewWState(loser, g, p, 0));
	p.SetLState(loser, NewLState(loser, g, p, 1));
	p.SetLState(winner, NewLState(winner, g, p, 0));

	p.SetLastFight(winner, period);
	p.SetLastFight(loser, period);
	
	p.Num_wonIncrease(winner);
	p.Num_lostIncrease(loser);
	
	//DetailedOutputB(detail_first, detail_last, generation, thedetailedfile, g, p, indiv1, indiv2, winner, loser);	commented for speed
	ii+=2;
    }
}



// fight and update for War of attrition, SizeRatio
void FightAndUpdateWASR(const std::valarray<int> &FightingPairs, const PopulationGenome &g, PopulationNonGenome &p, const int &PopulationSize, const int &number_fighting_pairs, const double &fight_cost, const double &fight_gain, const double &strength_lw_ratio, const double &RHP_reliability, const double &cost_factor, const double &baseline, const int period, const int detail_first, const int detail_last, const int generation, ofstream &thedetailedfile) {

    int ii = 0;
    while (ii < 2*number_fighting_pairs) { // do this for every pair of fighters
	int indiv1 = FightingPairs[ii];
	int indiv2 = FightingPairs[ii+1];

	//evaluate LW state
	UpdateLW(indiv1, g, p, period);
	UpdateLW(indiv2, g, p, period);
	double LW1, LW2;
	LW1 = EvaluateLW(indiv1, g, p, baseline);
	LW2 = EvaluateLW(indiv2, g, p, baseline);

        //who wins?
	// double tmp1 = exp(RHP_reliability*((strength_lw_ratio*(p.GetStrength(indiv1) - p.GetStrength(indiv2))) + (LW1-LW2))); old
       	long double tmp1 = exp(RHP_reliability*((strength_lw_ratio*p.GetStrength(indiv1)*LW1)-(strength_lw_ratio * p.GetStrength(indiv2)* LW2)));
	long double p1win = tmp1/(1+tmp1);
	
	//who is the winner and who is the loser in this fight?
	int winner, loser;
	double LW_winner, LW_loser;
	if(p1win>= ReturnUniformClosed()) { 
	    winner = indiv1;
	    loser = indiv2;
	    LW_winner = LW1; // OK, not needed, but makes for more clear programm
	    LW_loser = LW2;
	} 
	else {
	    winner = indiv2;
	    loser = indiv1;
	    LW_winner = LW2;
	    LW_loser = LW1;
	}

	p.SetWState(winner, NewWState(winner, g, p, 1));
	p.SetWState(loser, NewWState(loser, g, p, 0));
	p.SetLState(loser, NewLState(loser, g, p, 1));
	p.SetLState(winner, NewLState(winner, g, p, 0));

	p.SetLastFight(winner, period);
	p.SetLastFight(loser, period);
	
	p.Num_wonIncrease(winner);
	p.Num_lostIncrease(loser);
	
	/* this is old
	double cost_fight_w = cost_factor * min(LW1,LW2)* (p.GetStrength(loser)/p.GetStrength(winner));
	double cost_fight_l = cost_factor * min(LW1,LW2)* (p.GetStrength(winner)/p.GetStrength(loser));
	*/	

	//xx: fix this; it might not make a lot of sense
	double cost_fight_w = cost_factor * (p.GetStrength(loser)*LW_loser/p.GetStrength(winner)*LW_winner);
	double cost_fight_l = cost_factor * (p.GetStrength(winner)*LW_winner/p.GetStrength(loser)*LW_loser);

	p.SetPartialScore(winner, fight_gain - cost_fight_w);
	p.SetPartialScore(loser,-(cost_fight_l));
    
	ii+=2;
    }
}



