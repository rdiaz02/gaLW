/***************************************************************************
                          ga.cpp  -  Genetic algorithm classes and methods
                             -------------------
    begin                : Mon Nov 27 2000
    copyright            : (C) 2000, 2004 by Ramon Diaz-Uriarte
    email                : rdiaz@ligarto.org
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#include<algorithm>
#include<valarray>
#include<vector>
#include<string>
#include<fstream>

#include"ga.h"
#include"RandomUtil.h" //my set of randon numbers and other related utilities




//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
///////////////////////                                       ////////////////////////
///////////////////////           PopulationGenome            ////////////////////////
///////////////////////                                       ////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

PopulationGenome::PopulationGenome(const int alleles, const int individuals) {
  number_of_alleles = alleles;
  population_size = individuals; 
  Score.resize(individuals);
  Fitness.resize(individuals);
  Score = 0.0;
  Fitness = 0.0; 
  Population.resize(individuals, vector<double> (alleles));
  Mating_Population.resize(individuals, vector<double> (alleles));
  for (int i=0; i<population_size; i++) {
    for(int j=0; j<number_of_alleles; j++) {
   	Population[i][j] = RandomAllele(j);
    }
  }

  // till the end is debugging
/*
  cout <<"\n ****************Initialization*****************\n";
  for (int i=0; i<population_size; i++) {
    for(int j=0; j<number_of_alleles; j++) {
      cout << Population[i][j]<<'\t';
    }
    cout << endl;  
}
*/

}
		
/**
 * Write the current state of the population (i.e., genotype for every individual) to a file.
 * You can also pass an integer (the second overloaded function), that will be printed in the same line;
 * these can be helpful to keep generation counter or other info.
*/

void PopulationGenome::OutputFileGenome(ofstream& thefile) {
	for (int i=0; i<number_of_alleles; i++) {
		for (int j=0; j<population_size; j++) thefile << GetGene(j, i) << '\t';
		}
	thefile << endl;
}	

void PopulationGenome::OutputFileGenome(ofstream& thefile, const int number) {
	thefile <<number <<'\t';
	for (int i=0; i<number_of_alleles; i++) {
		for (int j=0; j<population_size; j++) thefile << GetGene(j, i) << '\t';
		}
	thefile << endl;
}	

void PopulationGenome::ScreenOutScore() {
  cout << "\n Score: Mean = " << GetMeanRawScore() << "  Min = " << GetMinRawScore() << "  Max = " << GetMaxRawScore() << endl;
  cout << endl;
}


void PopulationGenome::SetFitnessLinear() {
    if(Score.min() < 0.0) Fitness=Score+(-Score.min()); //ensure all indivs have positive prob of being selected
    double sum_Fitness = Fitness.sum();
    Fitness = Fitness/sum_Fitness;

    //debugging
    /*
    cout << "*****  FITNESS **********"<<endl;
    for (int i = 0; i < population_size; i++) cout << Fitness[i]<< "  ";
    cout << endl;
    */

}


void PopulationGenome::SetFitnessTruncation(const double truncated_fraction) {
  valarray<double> tmp(population_size);
  tmp = Score;
  // first find the value below which all fitnesses are zero;
  int position_to_find = static_cast<int> (rint(population_size * truncated_fraction));
  //xx: debugg
//  cout << "\n Esto es la position " << position_to_find <<endl;
  nth_element(&tmp[0], &tmp[position_to_find], &tmp[population_size]);
  double cutting_value = tmp[position_to_find];
//cout << "\n Esto es el cutting value " << cutting_value << endl;
  for (int i =0; i < population_size; i++) {
    if(Score[i] < cutting_value) Fitness[i] = 0.0; else Fitness[i] = 1.0;
  }

  Fitness /= Fitness.sum();
  // or is this faster?: Fitness /=static_cast<double>(population_size - position_to_find);

    //debugging
    /*
    cout << "*****  FITNESS **********"<<endl;
    for (int i = 0; i < population_size; i++) cout << Fitness[i]<< "  ";
    cout << endl;
*/

}




void PopulationGenome::SetFitnessRank() {
    valarray<int> inverse_rank(population_size);
    inverse_rank = 0;
    // first rank individuals; 

    // Only works well if no two individuals are identical; otherwise,
    // we can get rank differences of more than 1 among successive ranks.
    // for an algorthm that gets successive values of ranks even for matching
    // cases see pairs-sort.cc

    for (int i = 0; i < population_size; i++) {
			for (int j=0; j< population_size; j++) if(Score[i] > Score[j]) ++inverse_rank[i];
    }
    // note: the worse individual ALWAYS gets a score of 0. Change this?

    double sum_ranks = static_cast<double>(inverse_rank.sum());
    for (int i = 0; i < population_size; i++) Fitness[i] = static_cast<double>(inverse_rank[i])/sum_ranks;

    //debugging
    /*
    cout << "*****  FITNESS **********"<<endl;
    for (int i = 0; i < population_size; i++) cout << Fitness[i]<< "  ";
    cout << endl;
    */

}

void PopulationGenome::Mating() {
	// I produce two offspring per mating, as in Mitchell, p. 12, or Bouskila et al., 1998; but not as in Sumida el al., 1990.
  int selected_parents = 0;
  vector<int> parents(population_size);

  // first, select the indices of the parents
  while (selected_parents < population_size) {
    parents[selected_parents] = Prob_Sampling_Index(Fitness);
    parents[++selected_parents] = Prob_Sampling_Index(Fitness);
    ++selected_parents;
  }
  // debugging
/*
  cout << "\n*** INDEXES of parents "<<endl;
  for (int i=0; i<population_size; i++) cout << parents[i]<< " ";
  cout << endl;
*/
  //Create the Mating_Population
  for(int i=0; i<population_size; i++)
    copy(Population[parents[i]].begin(), Population[parents[i]].end(), Mating_Population[i].begin());
  // till the end is debugging
  /*
  cout <<"\n ****************MatingPopulation*****************\n";
  for (int i=0; i<population_size; i++) {
    for(int j=0; j<number_of_alleles; j++) {
      cout << Mating_Population[i][j]<<'\t';
    }
    cout << endl;
    }
  */
}



void PopulationGenome::MatingOLG(const double replace_fraction, const double cover_prob, const double mutation_prob) {
  valarray<double> tmp(population_size);
  tmp = Score;
  // value below which all individuals are replaced
  int low_position_to_find = static_cast<int> (rint(population_size * replace_fraction));
  // ensure it is even:
  if (low_position_to_find%2) ++low_position_to_find;

  // value above which individuals are copied
  int high_position_to_find = population_size - low_position_to_find;

  //xx: debugg
  /*
  cout << "\n Esto es la position low " << low_position_to_find <<endl;
  cout << "\n Esto es la position high " << high_position_to_find <<endl;
  */

  nth_element(&tmp[0], &tmp[low_position_to_find], &tmp[population_size]);
  double low_cutting_value = tmp[low_position_to_find];

  nth_element(&tmp[0], &tmp[high_position_to_find], &tmp[population_size]);
  double high_cutting_value = tmp[high_position_to_find];

  /*  cout <<"\n Low cutting value " << low_cutting_value<<'\n';
  cout <<"\n High cutting value " << high_cutting_value<<'\n';
  cout <<"\n the old population \n";
  for (int i =0; i < population_size; i++) {
      cout << endl;
      for (int j =0; j < 5; j++) cout <<Population[i][j] <<" ";
      cout <<" Score "<< Score[i];
  }
  */

  PopulationGenome new_offspring(number_of_alleles, low_position_to_find);

  // copy the indivs who are to be copied; if many have max. value, not all will be selected as parents
  int j = 0;
  for (int i =0; (i < population_size) && (j<low_position_to_find); i++) {
    if(Score[i] >= high_cutting_value) {
	for(int l=0; l < number_of_alleles; l++) new_offspring.SetGene(j,l, Population[i][l]);
      ++j;
    }
  }

  /*
  cout <<"\n the new offspring \n";
  for (int i =0; i < low_position_to_find; i++) {
      cout << endl;
      for (int m =0; m < 5; m++) cout <<new_offspring.GetGene(i,m) <<" " <<flush;
  }
  */

  // cross-over among offspring and mutation
  // the following don't work, because they need a previous mating
  // which selects parents randomly
  new_offspring.Mating_Population = new_offspring.Population;
  new_offspring.CrossOver(cover_prob, "Uniform");
  new_offspring.MutateGenome(mutation_prob);


  // replace the lowest individuals by the new offspring; if there are many individuals with
  // euqal lowest score, not all will be replaced
  int k = 0;
  for (int i = 0; i < population_size && k<low_position_to_find; i++) {
    if(Score[i] < low_cutting_value) {
	for(int l = 0; l < number_of_alleles; l++) Population[i][l] = new_offspring.GetGene(k,l);
      ++k;
    }
  }
  /*
  cout <<"\n the new population \n";
  for (int i =0; i < population_size; i++) {
      cout << endl;
      for (int j =0; j < 5; j++) cout <<Population[i][j]  <<" ";
  }
  */

}
 

void PopulationGenome::CrossOver(const float cover_prob, const string type_cover) {
  if (type_cover=="Uniform") {
    int i =0;
    for (i=0; i< population_size; ){
      for(int j=0; j<number_of_alleles; j++) { 
	if(ReturnUniformClosed() < cover_prob) swap(Mating_Population[i][j],Mating_Population[i+1][j]);
      }
      i+=2;
    }
  }

  if (type_cover=="OnePoint") {
    int i=0;
    for (i=0; i< population_size; ){
      if(ReturnUniformClosed() < cover_prob) {
	int cross_over_point = 1+ReturnDiscreteUniform(number_of_alleles - 1);
	for (int j=0; j<cross_over_point; j++) swap(Mating_Population[i][j],Mating_Population[i+1][j]);
      }
   i+=2;
    }
  }

  // till the end is debugging
/*
  cout <<"\n ****************MatingPopulation after crossover*****************\n";
  for (int i=0; i<population_size; i++) {
    for(int j=0; j<number_of_alleles; j++) {
      cout << Mating_Population[i][j]<<'\t';
    }
    cout << endl;  
}
*/
}
 

void PopulationGenome::MutateGenome(const float umutate_prob) {
  for (int i=0; i<population_size; i++) {
    for(int j=0; j<number_of_alleles; j++) {
      if(ReturnUniformClosed() < umutate_prob) {
	Mating_Population[i][j] = MutateAllele(j, Mating_Population[i][j]);
      }
    }
  }
  Population = Mating_Population; //We DO change the value of the population here, after mutation

  // till the end is debugging
  /*
  cout <<"\n **************** THE NEW Population*****************\n";
  for (int i=0; i<population_size; i++) {
    for(int j=0; j<number_of_alleles; j++) {
      cout << Mating_Population[i][j]<<'\t';
    }
    cout << endl;
    }
  */
}


//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
///////////////////////                                       ////////////////////////
///////////////////////              GAControl                ////////////////////////
///////////////////////                                       ////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////


inline void GAControl::SetMeanRawScore(const int generation, const double value) {mean_raw_score = value;}
inline double GAControl::GetMeanRawScore(const int generation) {return mean_raw_score;}

GAControl::GAControl(const int max_number_of_generations, const int number_alleles, const int num_indiv) {
  num_alleles = number_alleles;
  num_individuals = num_indiv;
  mean_raw_score = 0.0;
  mean_traits.resize(num_alleles);
  SummaryQuartile.resize(3*number_alleles);
}

/*
int GAControl::GAMeanRawConvergence(const int generation, const float min_diff, const int stride) {
  int r_value; 
 if(!(generation%stride)){  
   cout << "\n NOW I am checking for convergence \n";
    if (abs (mean_raw_score[generation-1] - mean_raw_score[generation-stride-1]) < min_diff) r_value= 1; else r_value= 0; }
 else r_value= -1;
 return r_value;
}
*/


void GAControl::SetMeanTraits(const int generation, PopulationGenome& p) {
	for(int i = 0; i<num_alleles; i++) {
		double sum_tmp = 0.0;
		for (int j = 0; j< num_individuals; j++) sum_tmp+= p.GetGene(j, i);
		// cout << "\n esto es el allelo i = "<<i <<" y la suma es "<<sum_tmp<<endl;
		mean_traits[i] = sum_tmp/num_individuals;
		}
		/*
		cout << "\n Mean traits \n";
		for (int i=0; i< num_alleles; i++) cout <<mean_traits[generation][i] << " ";
		cout << endl;
		*/
}


/**
 * Obtain the median, 25th and 75th percentiles for each trait.
 * For reasons of space, these values ARE NOT stored for all generations,
 * but only for one generation; thus, you'll want to output them to a file or stdout.
*/

void GAControl::SetMedianQuartileTraits(PopulationGenome& p) {
	vector<double> tmp_vect(num_individuals);
	int stride = num_individuals/4;
	for(int i = 0; i<num_alleles; i++) {
		tmp_vect.assign(num_individuals,0.0);
		for (int j = 0; j <num_individuals; j++) tmp_vect[j] = p.GetGene(j,i);
		sort(tmp_vect.begin(), tmp_vect.end());
		SummaryQuartile[3*i] = (tmp_vect[stride-1]+tmp_vect[stride])/2; //25th percentile
		SummaryQuartile[(3*i)+1] = (tmp_vect[(2*stride)-1]+tmp_vect[2*stride])/2; //median
		SummaryQuartile[(3*i)+2] = (tmp_vect[(3*stride)-1]+tmp_vect[3*stride])/2; //75th perc.
		}
}
		

void GAControl::OutputFileMedianQuartileTraits(ofstream& thefile) {
	for (int i=0; i<(3*num_alleles); i++) thefile << SummaryQuartile[i] << '\t';
	thefile << endl;
}	


void GAControl::OutputFileMeanTraits(ofstream& thefile, const int generation) {
	for (int i=0; i<num_alleles; i++) thefile << mean_traits[i] << '\t';
	thefile << endl;
}	



void GAControl::ScreenOutQuartileTraits(const int generation, const string &s1) {
  cout <<"\n Population "<< s1 << " 25th perc., Median, and 75th. percentyle for each genotype at generation "<< generation <<endl;
	for (int i=0; i<(3*num_alleles); i++) cout << SummaryQuartile[i] << '\t';
	cout << endl;
}	



void GAControl::ScreenOutMeanTraits(const int generation, const string &s1) {
  cout << "Population " << s1 <<": mean genotype at each locus "; for (int i=0; i<num_alleles; i++) cout << mean_traits[i] << '\t';
}	
	

//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

// Testing:

/************************ COSAS NOT TESTADAS AUN **************************************

- Linear Fitness: kind of tested, and seems to work now.
- CrossOver: single Point; not tested at all.


****************************************************************************************/
